"""Apollo Live Engine — Data Replay Module.

Bar-by-bar CSV feeder that simulates live data arrival from historical
eod2 data. Used by ``signal_monitor.SignalMonitor`` to drive the live
scoring loop.

Design
------
The replay loads the full CSV once, computes all indicators (via
``load_eod2_stock``), and runs the Apollo scoring engine ONCE on the
full date range to get the complete ``daily_results`` list. It then
yields one bar at a time as a ``ReplayBar`` namedtuple.

This is O(N) total (not O(N²)) because we pre-compute scores once and
iterate through them. The "simulation" aspect is enforced by the
``SignalMonitor``: at bar N, it only uses data from bars 1..N (no
peeking ahead). The scores themselves are identical to what a real
live feed would produce, because ``run_backtest`` is deterministic and
the indicator history is fixed.

For real live mode (Phase 3+), this module will be replaced by a
``LiveBarFeed`` that reads from Kite/Broker API instead of CSV. The
``SignalMonitor`` interface stays the same.
"""

from __future__ import annotations

import sys
import os
from collections import namedtuple
from pathlib import Path
from typing import Iterator, Optional

import numpy as np
import pandas as pd

# Ensure project root is on sys.path so apollo_core is importable
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from apollo_core.constants import (
    ENTRY_THRESHOLD, EXIT_THRESHOLD,
    DIVERGENCE_RSI_DROP, DIVERGENCE_COOLDOWN,
    DEFAULT_MIN_TRADING_DAYS,
)
from apollo_core.ipo_lookup import is_ipo_by_listing_date
from apollo_core.trade_engine import run_backtest, run_ipo_backtest


# ---------------------------------------------------------------------------
# ReplayBar — one bar of replayed data
# ---------------------------------------------------------------------------

ReplayBar = namedtuple("ReplayBar", [
    "index",            # int — 0-based position in daily_results
    "date",             # pd.Timestamp — bar date
    "daily_result",     # dict — the full scoring result for this bar
                        #        (same shape as run_backtest daily_results entries)
    "df_d",             # pd.DataFrame — full daily DataFrame (with indicators)
    "df_4h",            # pd.DataFrame — full 4H DataFrame (with indicators)
    "df_w",             # pd.DataFrame — full weekly DataFrame (with indicators)
    "is_ipo",           # bool — whether this stock is in IPO period
    "bucket",           # str — Layer-1 bucket label
])


# ---------------------------------------------------------------------------
# BarReplay — the main replay class
# ---------------------------------------------------------------------------

class BarReplay:
    """Bar-by-bar replay of historical data for live signal simulation.

    Usage
    -----
    >>> replay = BarReplay(data_dir="data", symbol="CYIENTDLM",
    ...                    start_date="2024-01-01", end_date="2024-06-30")
    >>> for bar in replay.replay():
    ...     print(bar.date, bar.daily_result["total"])
    ...

    Parameters
    ----------
    data_dir : str
        Directory containing the eod2 CSV file ``{symbol}.csv``.
    symbol : str
        NSE stock symbol (e.g., "CYIENTDLM").
    start_date : str
        Replay start date (YYYY-MM-DD).
    end_date : str
        Replay end date (YYYY-MM-DD).
    entry_threshold : float
        Score at or above which a new entry is allowed (default 70).
    exit_threshold : float
        Score below which an in-trade position is exited (default 50).
    min_trading_days : int | None
        Minimum trading days for IPO detection. If None, uses
        ``DEFAULT_MIN_TRADING_DAYS`` from constants.
    """

    def __init__(
        self,
        data_dir: str,
        symbol: str,
        start_date: str,
        end_date: str,
        entry_threshold: float = ENTRY_THRESHOLD,
        exit_threshold: float = EXIT_THRESHOLD,
        min_trading_days: Optional[int] = None,
    ):
        self.data_dir = data_dir
        self.symbol = symbol
        self.start_date = start_date
        self.end_date = end_date
        self.entry_threshold = entry_threshold
        self.exit_threshold = exit_threshold
        self.min_trading_days = min_trading_days or DEFAULT_MIN_TRADING_DAYS

        # Lazy-loaded state
        self._prepared = False
        self._daily_results: list[dict] = []
        self._df_d: Optional[pd.DataFrame] = None
        self._df_4h: Optional[pd.DataFrame] = None
        self._df_w: Optional[pd.DataFrame] = None
        self._is_ipo: bool = False
        self._bucket: str = ""

    # ------------------------------------------------------------------
    # Preparation — load data, compute indicators, run scoring
    # ------------------------------------------------------------------

    def _prepare(self) -> None:
        """Load CSV, compute indicators, run scoring. Called once on first replay()."""
        if self._prepared:
            return

        # Import here to avoid circular import (eod2_loader imports apollo_core)
        from backtest_engine.eod2_loader import load_eod2_stock

        # (1) Load + compute indicators
        df_d, df_4h, df_w = load_eod2_stock(self.data_dir, self.symbol)

        # (2) IPO detection (same logic as backtest.py)
        ipo_detected, ipo_info = is_ipo_by_listing_date(
            self.symbol, df_d, self.min_trading_days,
        )
        ipo_listing_close = ipo_info.get("listing_close")

        if ipo_detected:
            self._is_ipo = True
            self._bucket = "IPO / New Listing"
            # (3a) IPO scoring path
            daily_df, daily_results, _ = run_ipo_backtest(
                df_d, df_4h, self.start_date, self.end_date,
                entry_threshold=self.entry_threshold,
                exit_threshold=self.exit_threshold,
                listing_close=ipo_listing_close,
            )
        else:
            self._is_ipo = False
            # (3b) Mature-stock path — bucket is reference-only (no gating)
            from apollo_core.bucket_classifier import classify_stock_bucket
            layer1_bucket, _ = classify_stock_bucket(
                df_d, min_trading_days=self.min_trading_days,
            )
            self._bucket = layer1_bucket

            daily_df, daily_results, _ = run_backtest(
                df_d, df_4h, df_w, self.start_date, self.end_date,
                entry_threshold=self.entry_threshold,
                exit_threshold=self.exit_threshold,
            )

        self._daily_results = daily_results
        self._df_d = df_d
        self._df_4h = df_4h
        self._df_w = df_w
        self._prepared = True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def replay(self) -> Iterator[ReplayBar]:
        """Yield ``ReplayBar`` objects, one per trading day in the date range.

        Order is chronological (oldest first). Each bar contains the full
        ``daily_result`` dict (score, signals, bucket, etc.) plus references
        to the full DataFrames (for any lookups the monitor needs).
        """
        self._prepare()
        for i, result in enumerate(self._daily_results):
            yield ReplayBar(
                index=i,
                date=result["date"],
                daily_result=result,
                df_d=self._df_d,
                df_4h=self._df_4h,
                df_w=self._df_w,
                is_ipo=self._is_ipo,
                bucket=self._bucket,
            )

    @property
    def n_bars(self) -> int:
        """Total number of bars that will be yielded by replay()."""
        self._prepare()
        return len(self._daily_results)

    @property
    def is_ipo(self) -> bool:
        """Whether this stock is in IPO period (uses IPO scoring path)."""
        self._prepare()
        return self._is_ipo

    @property
    def bucket(self) -> str:
        """Layer-1 bucket label (reference-only, never a gate)."""
        self._prepare()
        return self._bucket
