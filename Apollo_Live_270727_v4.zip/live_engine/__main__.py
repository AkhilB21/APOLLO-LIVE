"""Enable `python -m live_engine` to invoke the CLI."""

from __future__ import annotations

import sys

from live_engine.cli import main

if __name__ == "__main__":
    sys.exit(main())
