"""Generate a frozen baseline of v3.4.2's trade output on CYIENTDLM.

This script runs the v3.4.2 backtest on CYIENTDLM (data/CYIENTDLM.csv)
and saves the full trade event list as a JSON file. The pre-flight test
suite's Test 13 will compare v3.5's output against this baseline to prove
byte-for-byte equivalence.

Usage:
    python tests/generate_baseline_v342.py

Output:
    tests/baseline_v342_cyientdlm.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backtest_engine.backtest import run_stock_backtest

DATA_DIR = PROJECT_ROOT / "data"
CSV_PATH = DATA_DIR / "CYIENTDLM.csv"
BASELINE_PATH = PROJECT_ROOT / "tests" / "baseline_v342_cyientdlm.json"


def main():
    if not CSV_PATH.exists():
        print(f"ERROR: {CSV_PATH} not found", file=sys.stderr)
        sys.exit(1)

    print(f"Running backtest on CYIENTDLM (data range 2022-01-01 to 2026-07-24)...")
    result = run_stock_backtest(
        data_dir=str(DATA_DIR),
        symbol="CYIENTDLM",
        start_date="2022-01-01",
        end_date="2026-07-24",
        exit_mode="NONE",
    )

    daily_df = result["daily_df"]
    trades = result["trades"]

    # Convert any numpy/pandas types to native Python types for JSON serialization
    def _to_native(obj):
        import numpy as np
        import pandas as pd
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, pd.Timestamp):
            return obj.isoformat()
        if isinstance(obj, dict):
            return {k: _to_native(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_to_native(v) for v in obj]
        return obj

    baseline = {
        "symbol": "CYIENTDLM",
        "date_range": "2022-01-01 to 2026-07-24",
        "exit_mode": "NONE",
        "n_daily_rows": len(daily_df),
        # NOTE: result["n_trades"] is the count of completed round-trip trades (EXITs only).
        # result["trades"] is the full events list (ENTRY + HOLD-* + EXIT events).
        # The baseline stores BOTH so the test can verify whichever is relevant.
        "n_trades": int(result["n_trades"]),       # count of completed EXIT trades (19)
        "n_events": len(trades),                   # full events list length (302)
        "cum_pnl": float(result["cum_pnl"]),
        "win_rate": float(result["win_rate"]),
        "trades": _to_native(trades),              # full events list for field-by-field comparison
    }

    BASELINE_PATH.write_text(json.dumps(baseline, indent=2, default=str), encoding="utf-8")
    print(f"\nBaseline written to: {BASELINE_PATH}")
    print(f"  Symbol:        {baseline['symbol']}")
    print(f"  Date range:    {baseline['date_range']}")
    print(f"  Exit mode:     {baseline['exit_mode']}")
    print(f"  Daily rows:    {baseline['n_daily_rows']}")
    print(f"  n_trades:      {baseline['n_trades']}  (completed EXIT trades)")
    print(f"  n_events:      {baseline['n_events']}  (ENTRY + HOLD + EXIT events)")
    print(f"  Cum P&L:       {baseline['cum_pnl']:.2f}%")
    print(f"  Win rate:      {baseline['win_rate']:.1f}%")


if __name__ == "__main__":
    main()
