"""Smoke test: run the live signal monitor on CYIENTDLM end-to-end.

Verifies:
1. BarReplay loads data and yields bars
2. SignalMonitor runs over all bars without crashing
3. Alerts are emitted and saved to state_store
4. State persistence works (resume from saved state)

Run:
    cd <project_root>
    python tests/smoke_live.py
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

# Ensure project root is on sys.path
THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from live_engine.data_replay import BarReplay
from live_engine.state_store import StateStore
from live_engine.signal_monitor import SignalMonitor, ALERT_ENTRY, ALERT_EXIT


def main() -> int:
    symbol = "CYIENTDLM"
    data_dir = str(PROJECT_ROOT / "data")
    start_date = "2024-01-01"
    end_date = "2024-06-30"

    print(f"=== Smoke Test: Live Monitor on {symbol} ===")
    print(f"Date range: {start_date} → {end_date}")
    print()

    # Check CSV exists
    csv_path = Path(data_dir) / f"{symbol}.csv"
    if not csv_path.exists():
        print(f"FAIL: CSV not found at {csv_path}")
        return 1

    # 1. Build replay
    print("[1] Building BarReplay...")
    replay = BarReplay(
        data_dir=data_dir,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
    )
    n_bars = replay.n_bars
    print(f"    Replay prepared: {n_bars} bars, is_ipo={replay.is_ipo}, bucket='{replay.bucket}'")
    if n_bars == 0:
        print("FAIL: No bars in replay")
        return 1

    # 2. Run monitor with in-memory DB
    print()
    print("[2] Running SignalMonitor (fresh start)...")
    alerts_received: list[dict] = []

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test_state.db"
        with StateStore(db_path) as store:
            monitor = SignalMonitor(
                replay=replay,
                state_store=store,
                alert_callback=lambda a: alerts_received.append(a),
                exit_mode="NONE",
                auto_confirm_exit=True,
            )
            summary = monitor.run(resume=False, verbose=False)

        print(f"    Bars processed: {summary['n_bars_processed']}")
        print(f"    Alerts emitted: {summary['n_alerts']}")
        print(f"      ENTRY:    {summary['n_entries']}")
        print(f"      EXIT:     {summary['n_exits']}")
        print(f"      HOLD:     {summary['n_holds']}")
        print(f"      WAIT:     {summary['n_waits']}")
        print(f"      COOLDOWN: {summary['n_cooldowns']}")
        print(f"    Final in_trade: {summary['final_in_trade']}")

        # 3. Verify alerts saved to DB
        print()
        print("[3] Verifying alerts saved to state_store...")
        with StateStore(db_path) as store2:
            db_alerts = store2.list_alerts(symbol=symbol)
            print(f"    Alerts in DB: {len(db_alerts)}")
            if len(db_alerts) != len(alerts_received):
                print(f"    WARN: callback got {len(alerts_received)}, DB has {len(db_alerts)}")

            # 4. Verify state persistence
            print()
            print("[4] Verifying state persistence (resume)...")
            replay2 = BarReplay(
                data_dir=data_dir, symbol=symbol,
                start_date=start_date, end_date=end_date,
            )
            with StateStore(db_path) as store3:
                monitor2 = SignalMonitor(
                    replay=replay2,
                    state_store=store3,
                    alert_callback=lambda a: None,
                    exit_mode="NONE",
                )
                summary2 = monitor2.run(resume=True, verbose=False)

            print(f"    Resume run — bars processed: {summary2['n_bars_processed']}")
            print(f"    Resume run — bars skipped:   {summary2['n_bars_skipped']}")
            print(f"    Resume run — new alerts:     {summary2['n_alerts']}")

            if summary2['n_bars_processed'] != 0:
                print(f"    FAIL: resume should skip all bars, but processed {summary2['n_bars_processed']}")
                return 1
            print(f"    PASS: resume correctly skipped all {summary2['n_bars_skipped']} bars")

    # 5. Print first 3 ENTRY alerts as sample
    print()
    print("[5] Sample ENTRY alerts (first 3):")
    entry_alerts = [a for a in alerts_received if a["alert_type"] == ALERT_ENTRY]
    for a in entry_alerts[:3]:
        ts = a["timestamp"]
        ts_str = ts.strftime("%Y-%m-%d") if hasattr(ts, "strftime") else str(ts)
        print(f"    [{ts_str}] {a['message'][:120]}")

    print()
    print("=== SMOKE TEST PASSED ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
