"""Quick diagnostic: print backtest exit reasons to identify the divergence."""
from __future__ import annotations
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backtest_engine.backtest import run_stock_backtest

result = run_stock_backtest(
    data_dir=str(PROJECT_ROOT / "data"),
    symbol="CYIENTDLM",
    start_date="2024-01-01",
    end_date="2024-06-30",
    exit_mode="NONE",
)
print("=== Backtest EXIT events ===")
for e in result["trades"]:
    if e["type"] == "EXIT":
        print(f"  {e['date']}  class={e['classification']!r:20s}  reason={e.get('exit_reason', '')[:80]}")
