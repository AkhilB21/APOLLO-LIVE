"""Consistency test: live monitor decisions must match backtest decisions.

This is THE critical correctness test for Step 2. The whole point of
the detect/execute split (Step 1) was to enable the live monitor to
use the SAME detect_exit_triggers() function as the backtest. If the
live monitor produces different entry/exit decisions than the backtest
on the same data, the split failed.

Method
------
1. Run the backtest on CYIENTDLM (2024-01-01 → 2024-06-30, exit_mode=NONE).
   Extract ENTRY and EXIT events.
2. Run the live monitor on the same symbol/date-range/exit-mode.
   Extract ENTRY and EXIT alerts.
3. Compare:
   - Same number of ENTRY events
   - Same number of EXIT events
   - Same entry dates
   - Same exit dates
   - Same exit reasons (primary_class)

The backtest and live monitor use DIFFERENT cooldown tracking (backtest
uses bar index, live uses date). This may cause divergence in rare edge
cases where a cooldown period spans a weekend. We allow up to 1
mismatch in 30 trades (3.3%) as a tolerance for this.

Run:
    cd <project_root>
    python tests/consistency_vs_backtest.py
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pandas as pd

# Ensure project root is on sys.path
THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backtest_engine.backtest import run_stock_backtest
from live_engine.data_replay import BarReplay
from live_engine.state_store import StateStore
from live_engine.signal_monitor import SignalMonitor, ALERT_ENTRY, ALERT_EXIT


def run_backtest_baseline(symbol: str, data_dir: str,
                           start_date: str, end_date: str) -> list[dict]:
    """Run the backtest and return ENTRY + EXIT events.

    NOTE: PERIOD_END exits are filtered out — they are a backtest-only
    artifact (closes any open position at end of data range). In live
    mode, positions stay open until a real exit signal fires. So we
    exclude them from the comparison.
    """
    result = run_stock_backtest(
        data_dir=data_dir,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        exit_mode="NONE",  # match live monitor's default
    )
    events = []
    for e in result.get("trades", []):
        if e["type"] == "ENTRY":
            events.append({
                "type": "ENTRY",
                "date": pd.Timestamp(e["date"]),
                "score": float(e["score"]),
                "close": float(e["close"]),
            })
        elif e["type"] == "EXIT":
            # Skip PERIOD_END exits — backtest-only artifact
            if e.get("exit_reason") == "PERIOD_END":
                continue
            events.append({
                "type": "EXIT",
                "date": pd.Timestamp(e["date"]),
                "score": float(e["score"]),
                "close": float(e["close"]),
                "exit_reason": e.get("exit_reason", ""),
                "classification": e.get("classification", ""),
            })
    return events


def run_live_monitor(symbol: str, data_dir: str,
                      start_date: str, end_date: str) -> list[dict]:
    """Run the live monitor and return ENTRY + EXIT alerts."""
    replay = BarReplay(
        data_dir=data_dir, symbol=symbol,
        start_date=start_date, end_date=end_date,
    )
    alerts_received: list[dict] = []
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test_state.db"
        with StateStore(db_path) as store:
            monitor = SignalMonitor(
                replay=replay,
                state_store=store,
                alert_callback=lambda a: alerts_received.append(a),
                exit_mode="NONE",
                auto_confirm_exit=True,
            )
            monitor.run(resume=False, verbose=False)

    events = []
    for a in alerts_received:
        if a["alert_type"] == ALERT_ENTRY:
            events.append({
                "type": "ENTRY",
                "date": pd.Timestamp(a["timestamp"]),
                "score": float(a["payload"]["score"]),
                "close": float(a["payload"]["close"]),
            })
        elif a["alert_type"] == ALERT_EXIT:
            events.append({
                "type": "EXIT",
                "date": pd.Timestamp(a["timestamp"]),
                "score": float(a["payload"]["score"]),
                "close": float(a["payload"]["close"]),
                "exit_reason": a["payload"].get("primary_reason", ""),
                "classification": a["payload"].get("primary_class", ""),
            })
    return events


def compare_events(backtest_events: list[dict],
                    live_events: list[dict]) -> tuple[int, int, list[str]]:
    """Compare backtest and live event lists. Returns (matches, mismatches, details)."""
    matches = 0
    mismatches = 0
    details: list[str] = []

    # Compare ENTRY events
    bt_entries = [e for e in backtest_events if e["type"] == "ENTRY"]
    live_entries = [e for e in live_events if e["type"] == "ENTRY"]

    if len(bt_entries) != len(live_entries):
        mismatches += 1
        details.append(
            f"ENTRY count mismatch: backtest={len(bt_entries)}, live={len(live_entries)}"
        )
    else:
        for i, (b, l) in enumerate(zip(bt_entries, live_entries)):
            if b["date"] != l["date"]:
                mismatches += 1
                details.append(
                    f"ENTRY[{i}] date mismatch: backtest={b['date']}, live={l['date']}"
                )
            elif abs(b["score"] - l["score"]) > 0.01:
                mismatches += 1
                details.append(
                    f"ENTRY[{i}] score mismatch: backtest={b['score']}, live={l['score']}"
                )
            else:
                matches += 1

    # Compare EXIT events
    bt_exits = [e for e in backtest_events if e["type"] == "EXIT"]
    live_exits = [e for e in live_events if e["type"] == "EXIT"]

    if len(bt_exits) != len(live_exits):
        mismatches += 1
        details.append(
            f"EXIT count mismatch: backtest={len(bt_exits)}, live={len(live_exits)}"
        )
    else:
        for i, (b, l) in enumerate(zip(bt_exits, live_exits)):
            if b["date"] != l["date"]:
                mismatches += 1
                details.append(
                    f"EXIT[{i}] date mismatch: backtest={b['date']}, live={l['date']}"
                )
            elif b["classification"] != l["classification"]:
                mismatches += 1
                details.append(
                    f"EXIT[{i}] class mismatch: backtest='{b['classification']}', live='{l['classification']}'"
                )
            else:
                matches += 1

    return matches, mismatches, details


def main() -> int:
    symbol = "CYIENTDLM"
    data_dir = str(PROJECT_ROOT / "data")
    start_date = "2024-01-01"
    end_date = "2024-06-30"

    print(f"=== Consistency Test: Live Monitor vs Backtest ===")
    print(f"Symbol: {symbol}, Range: {start_date} → {end_date}")
    print(f"Exit mode: NONE (both)")
    print()

    # 1. Backtest baseline
    print("[1] Running backtest baseline...")
    bt_events = run_backtest_baseline(symbol, data_dir, start_date, end_date)
    bt_entries = [e for e in bt_events if e["type"] == "ENTRY"]
    bt_exits = [e for e in bt_events if e["type"] == "EXIT"]
    print(f"    Backtest: {len(bt_entries)} ENTRY, {len(bt_exits)} EXIT")

    # 2. Live monitor
    print()
    print("[2] Running live monitor...")
    live_events = run_live_monitor(symbol, data_dir, start_date, end_date)
    live_entries = [e for e in live_events if e["type"] == "ENTRY"]
    live_exits = [e for e in live_events if e["type"] == "EXIT"]
    print(f"    Live:    {len(live_entries)} ENTRY, {len(live_exits)} EXIT")

    # 3. Compare
    print()
    print("[3] Comparing decisions...")
    matches, mismatches, details = compare_events(bt_events, live_events)

    print(f"    Matches:    {matches}")
    print(f"    Mismatches: {mismatches}")
    if details:
        print("    Details:")
        for d in details:
            print(f"      - {d}")

    print()
    total_comparisons = matches + mismatches
    if total_comparisons == 0:
        print("FAIL: No comparisons made (both event lists empty?)")
        return 1

    match_pct = matches / total_comparisons * 100
    print(f"Match rate: {match_pct:.1f}%")

    # Tolerance: allow 0 mismatches (live monitor should match backtest exactly
    # on same exit_mode=NONE, since cooldown is approximated but the threshold
    # is the same — divergences are very rare)
    if mismatches == 0:
        print()
        print("=== CONSISTENCY TEST PASSED — Live decisions match backtest exactly ===")
        return 0
    elif match_pct >= 95.0:
        print()
        print(f"=== CONSISTENCY TEST PASSED (with tolerance) — {match_pct:.1f}% match ===")
        return 0
    else:
        print()
        print(f"=== CONSISTENCY TEST FAILED — only {match_pct:.1f}% match ===")
        return 1


if __name__ == "__main__":
    sys.exit(main())
