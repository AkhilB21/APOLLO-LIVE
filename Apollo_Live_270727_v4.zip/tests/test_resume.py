"""Crash-recovery test: monitor processes first half, stops, resumes, finishes.

Verifies that:
1. Monitor processes bars 1..N, saves state, stops
2. New monitor instance loads state, processes bars N+1..end
3. Combined decisions match a single uninterrupted run

Run:
    cd <project_root>
    python tests/test_resume.py
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pandas as pd

# Ensure project root is on sys.path
THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from live_engine.data_replay import BarReplay
from live_engine.state_store import StateStore
from live_engine.signal_monitor import SignalMonitor, ALERT_ENTRY, ALERT_EXIT


def collect_alerts(symbol: str, data_dir: str, start: str, end: str,
                    db_path: Path, resume: bool) -> tuple[list[dict], dict]:
    """Run the monitor (resume or fresh) and return all alerts + summary."""
    replay = BarReplay(data_dir=data_dir, symbol=symbol,
                        start_date=start, end_date=end)
    alerts: list[dict] = []
    with StateStore(db_path) as store:
        monitor = SignalMonitor(
            replay=replay,
            state_store=store,
            alert_callback=lambda a: alerts.append(a),
            exit_mode="NONE",
            auto_confirm_exit=True,
        )
        summary = monitor.run(resume=resume, verbose=False)
    return alerts, summary


def main() -> int:
    symbol = "CYIENTDLM"
    data_dir = str(PROJECT_ROOT / "data")
    full_start = "2024-01-01"
    full_end = "2024-06-30"

    print("=== Crash-Recovery Test ===")
    print(f"Symbol: {symbol}, Full range: {full_start} → {full_end}")
    print()

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "state.db"

        # 1. Single uninterrupted run (baseline)
        print("[1] Baseline: single uninterrupted run...")
        baseline_alerts, base_summary = collect_alerts(
            symbol, data_dir, full_start, full_end,
            db_path=Path(tmpdir) / "baseline.db",
            resume=False,
        )
        print(f"    Bars: {base_summary['n_bars_processed']}, "
              f"Alerts: {base_summary['n_alerts']}, "
              f"Entries: {base_summary['n_entries']}, Exits: {base_summary['n_exits']}")

        # 2. First half run (stops mid-way — simulate crash)
        print()
        print("[2] First-half run (Jan 1 → Mar 31)...")
        first_alerts, first_summary = collect_alerts(
            symbol, data_dir, full_start, "2024-03-31",
            db_path=db_path,
            resume=False,
        )
        print(f"    Bars: {first_summary['n_bars_processed']}, "
              f"Alerts: {first_summary['n_alerts']}, "
              f"Entries: {first_summary['n_entries']}, Exits: {first_summary['n_exits']}")
        print(f"    Final in_trade: {first_summary['final_in_trade']}")

        # 3. Resume run (full range — should skip first half, process rest)
        print()
        print("[3] Resume run (Jan 1 → Jun 30, should skip first half)...")
        resume_alerts, resume_summary = collect_alerts(
            symbol, data_dir, full_start, full_end,
            db_path=db_path,
            resume=True,
        )
        print(f"    Bars processed: {resume_summary['n_bars_processed']}, "
              f"Bars skipped: {resume_summary['n_bars_skipped']}")
        print(f"    New alerts: {resume_summary['n_alerts']}, "
              f"Entries: {resume_summary['n_entries']}, Exits: {resume_summary['n_exits']}")

        # 4. Compare
        print()
        print("[4] Comparing decisions...")

        # Combined = first-half alerts + resume-run new alerts (excluding STARTUP)
        def filter_real(alerts):
            return [a for a in alerts if a["alert_type"] != "STARTUP"]

        combined = filter_real(first_alerts) + filter_real(resume_alerts)
        baseline = filter_real(baseline_alerts)

        # Compare ENTRY + EXIT decisions
        def decisions(alerts):
            return [(a["alert_type"], a["timestamp"]) for a in alerts
                    if a["alert_type"] in (ALERT_ENTRY, ALERT_EXIT)]

        combined_decisions = decisions(combined)
        baseline_decisions = decisions(baseline)

        print(f"    Baseline decisions:   {len(baseline_decisions)}")
        print(f"    Combined decisions:   {len(combined_decisions)}")

        if len(baseline_decisions) != len(combined_decisions):
            print("    FAIL: Decision count mismatch")
            print(f"    Baseline: {baseline_decisions}")
            print(f"    Combined: {combined_decisions}")
            return 1

        mismatches = 0
        for i, (b, c) in enumerate(zip(baseline_decisions, combined_decisions)):
            if b != c:
                print(f"    Mismatch at {i}: baseline={b}, combined={c}")
                mismatches += 1

        if mismatches > 0:
            print(f"    FAIL: {mismatches} mismatches")
            return 1

        print(f"    All {len(baseline_decisions)} decisions match exactly")
        print()
        print("=== CRASH-RECOVERY TEST PASSED ===")
        print("Monitor can stop mid-run, restart, and produce identical decisions.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
