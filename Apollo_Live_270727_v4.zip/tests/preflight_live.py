"""Apollo Live v1.4 — Pre-flight Test Suite.

Run this BEFORE packaging any live-engine zip. If any test fails, the
zip is NOT shippable. No exceptions.

Usage:
    cd <project_root>
    python tests/preflight_live.py

Exit codes:
    0 — all tests passed (safe to package)
    1 — one or more tests failed (DO NOT package)
"""

from __future__ import annotations

import os
import sys
import re
import tempfile
import traceback
from pathlib import Path

import pandas as pd

# Current shipped version — bump this on every release.
CURRENT_VERSION = "v1.4"
CURRENT_VERSION_DOTTED = "1.4"
ENGINE_NAME = "Apollo Live"

# Ensure project root is on sys.path
THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


# =========================================================================
# Test framework
# =========================================================================

class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.message = ""
        self.details = ""

    def __repr__(self):
        status = "PASS" if self.passed else "FAIL"
        return f"[{status}] {self.name}: {self.message}"


results: list[TestResult] = []


def run_test(name: str, fn):
    """Run a single test function and capture its result."""
    r = TestResult(name)
    try:
        msg, details = fn()
        r.passed = True
        r.message = msg
        r.details = details or ""
    except AssertionError as e:
        r.message = f"ASSERT FAILED: {e}"
        r.details = traceback.format_exc()
    except Exception as e:
        r.message = f"ERROR: {type(e).__name__}: {e}"
        r.details = traceback.format_exc()
    results.append(r)
    status = "PASS" if r.passed else "FAIL"
    print(f"  [{status}] {name}: {r.message}")
    if not r.passed and r.details:
        # Print full traceback for failures
        for line in r.details.splitlines()[-10:]:
            print(f"          {line}")
    return r


# =========================================================================
# Tests
# =========================================================================

def test_syntax_all_files():
    """Test 1: Syntax check every .py file in the project."""
    import ast
    py_files = []
    for root, dirs, files in os.walk(PROJECT_ROOT):
        # Skip __pycache__ and .git
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
        for f in files:
            if f.endswith(".py"):
                py_files.append(Path(root) / f)

    failures = []
    for py_file in py_files:
        try:
            src = py_file.read_text(encoding="utf-8")
            ast.parse(src, filename=str(py_file))
        except SyntaxError as e:
            failures.append(f"{py_file.relative_to(PROJECT_ROOT)}: {e}")

    assert not failures, f"{len(failures)} files failed syntax check:\n" + "\n".join(failures)
    return f"All {len(py_files)} Python files passed syntax check", ""


def test_future_import_ordering():
    """Test 2: __future__ imports must be the first statement after the module docstring."""
    py_files = []
    for root, dirs, files in os.walk(PROJECT_ROOT):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
        for f in files:
            if f.endswith(".py"):
                py_files.append(Path(root) / f)

    failures = []
    for py_file in py_files:
        src = py_file.read_text(encoding="utf-8")
        if "from __future__" not in src:
            continue  # __future__ import is optional
        # Parse the AST
        import ast
        tree = ast.parse(src, filename=str(py_file))
        # Find the position of the first non-docstring statement
        first_stmt_idx = None
        for i, node in enumerate(tree.body):
            # Docstring is an Expr with a Constant str value
            if (isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)
                    and isinstance(node.value.value, str)):
                continue
            first_stmt_idx = i
            break
        if first_stmt_idx is None:
            continue  # file is empty or just a docstring
        first_stmt = tree.body[first_stmt_idx]
        # Check it's an ImportFrom with module='__future__'
        ok = (isinstance(first_stmt, ast.ImportFrom)
              and first_stmt.module == "__future__")
        if not ok:
            failures.append(
                f"{py_file.relative_to(PROJECT_ROOT)}: first statement "
                f"(line {first_stmt.lineno}) is not 'from __future__ import ...'"
            )

    assert not failures, f"{len(failures)} files have bad __future__ ordering:\n" + "\n".join(failures)
    return f"All __future__ imports correctly ordered", ""


def test_import_all_modules():
    """Test 3: Import every live_engine module + apollo_core modules."""
    modules_to_import = [
        "apollo_core",
        "apollo_core.types",
        "apollo_core.constants",
        "apollo_core.indicators",
        "apollo_core.bucket_classifier",
        "apollo_core.ipo_lookup",
        "apollo_core.scoring",
        "apollo_core.trade_engine",
        "live_engine",
        "live_engine.data_replay",
        "live_engine.state_store",
        "live_engine.signal_monitor",
        "live_engine.cli",
        "live_engine.dashboard",
        "live_engine.run_live",
        # v1.3 additions
        "live_engine.watchlist",
        "live_engine.multi_monitor",
        # v1.4 additions
        "live_engine.alert_manager",
        "live_engine.daily_report",
        "live_engine.run_headless",
        "live_engine.live_feed",
    ]
    failures = []
    for mod in modules_to_import:
        try:
            __import__(mod)
        except Exception as e:
            failures.append(f"{mod}: {type(e).__name__}: {e}")

    assert not failures, f"{len(failures)} import failures:\n" + "\n".join(failures)
    return f"All {len(modules_to_import)} modules imported successfully", ""


def test_required_files_present():
    """Test 4: All required files are present in the project."""
    required = [
        "apollo_core/__init__.py",
        "apollo_core/types.py",
        "apollo_core/constants.py",
        "apollo_core/indicators.py",
        "apollo_core/bucket_classifier.py",
        "apollo_core/ipo_lookup.py",
        "apollo_core/scoring.py",
        "apollo_core/trade_engine.py",
        "live_engine/__init__.py",
        "live_engine/__main__.py",
        "live_engine/data_replay.py",
        "live_engine/state_store.py",
        "live_engine/signal_monitor.py",
        "live_engine/cli.py",
        "live_engine/dashboard.py",
        "live_engine/run_live.py",
        # v1.3 additions
        "live_engine/watchlist.py",
        "live_engine/multi_monitor.py",
        # v1.4 additions
        "live_engine/alert_manager.py",
        "live_engine/daily_report.py",
        "live_engine/run_headless.py",
        "live_engine/live_feed.py",
        "backtest_engine/__init__.py",
        "backtest_engine/eod2_loader.py",
        "backtest_engine/backtest.py",
        "tests/preflight_live.py",
        "tests/baseline_v342_cyientdlm.json",
        "CHANGELOG.md",
        "README.md",
        "requirements.txt",
        "run_apollo_live.bat",
        "ipo_listing_dates.json",
        "data/CYIENTDLM.csv",
    ]
    missing = [f for f in required if not (PROJECT_ROOT / f).exists()]
    assert not missing, f"Missing {len(missing)} files: {missing}"
    return f"All {len(required)} required files present", ""


def test_requirements_file():
    """Test 5: requirements.txt is non-empty and parseable."""
    req_path = PROJECT_ROOT / "requirements.txt"
    assert req_path.exists(), "requirements.txt not found"
    lines = [l.strip() for l in req_path.read_text().splitlines()
             if l.strip() and not l.startswith("#")]
    assert len(lines) >= 3, f"Expected at least 3 packages, got {len(lines)}"
    # Must include critical packages
    req_text = req_path.read_text().lower()
    for critical in ["pandas", "numpy", "streamlit"]:
        assert critical in req_text, f"Missing critical package: {critical}"
    return f"requirements.txt OK ({len(lines)} packages)", ""


def test_version_consistency():
    """Test 6: Version string must appear consistently across files."""
    # live_engine/__init__.py must contain __version__ = "1.0"
    init_src = (PROJECT_ROOT / "live_engine" / "__init__.py").read_text(encoding="utf-8")
    assert f'__version__ = "{CURRENT_VERSION_DOTTED}"' in init_src, \
        f'live_engine/__init__.py does not contain __version__ = "{CURRENT_VERSION_DOTTED}"'

    # CHANGELOG.md must have a section for the current version
    changelog = (PROJECT_ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    assert f"## {ENGINE_NAME} {CURRENT_VERSION}" in changelog or f"## {CURRENT_VERSION}" in changelog, \
        f"CHANGELOG.md does not contain a '## {ENGINE_NAME} {CURRENT_VERSION}' or '## {CURRENT_VERSION}' section"

    # CHANGELOG must have a section for the current version.
    # (CHANGELOG may contain BOTH engines' history — Apollo Live at top,
    # Apollo Backtest below. We just require v1.0 to exist as a section.)
    sections = [l for l in changelog.splitlines() if l.startswith("## ")]
    assert sections, "CHANGELOG.md has no '## ' sections"
    assert any(CURRENT_VERSION in s for s in sections), \
        f"No '## ... {CURRENT_VERSION} ...' section in CHANGELOG.md. Sections: {sections[:3]}"

    return f"Version {CURRENT_VERSION} consistent across live_engine/__init__.py and CHANGELOG.md", ""


def test_changelog_in_zip_root():
    """Test 7: CHANGELOG.md exists at project root (will be at zip root)."""
    changelog = PROJECT_ROOT / "CHANGELOG.md"
    assert changelog.exists(), "CHANGELOG.md not found at project root"
    content = changelog.read_text(encoding="utf-8")
    assert len(content) > 100, f"CHANGELOG.md is suspiciously short ({len(content)} chars)"
    assert "Apollo Live" in content or CURRENT_VERSION in content, \
        f"CHANGELOG.md does not mention 'Apollo Live' or '{CURRENT_VERSION}'"
    return f"CHANGELOG.md is present at project root and references Apollo Live {CURRENT_VERSION}", ""


def test_data_replay_loads_cyientdlm():
    """Test 8: BarReplay loads CYIENTDLM CSV and yields bars."""
    from live_engine.data_replay import BarReplay
    replay = BarReplay(
        data_dir=str(PROJECT_ROOT / "data"),
        symbol="CYIENTDLM",
        start_date="2024-01-01",
        end_date="2024-06-30",
    )
    n_bars = replay.n_bars
    assert n_bars > 0, "BarReplay yielded 0 bars for CYIENTDLM"
    assert n_bars > 50, f"Expected >50 bars for 6-month range, got {n_bars}"

    # Verify replay() yields ReplayBar namedtuples
    bars = list(replay.replay())
    assert len(bars) == n_bars
    first = bars[0]
    assert hasattr(first, "daily_result"), "ReplayBar missing daily_result"
    assert "total" in first.daily_result, "daily_result missing 'total' key"
    assert "date" in first.daily_result, "daily_result missing 'date' key"

    return f"BarReplay loaded CYIENTDLM: {n_bars} bars, is_ipo={replay.is_ipo}, bucket='{replay.bucket}'", ""


def test_state_store_roundtrip():
    """Test 9: StateStore save/load roundtrip preserves Position (including v1.1 pending_exit fields)."""
    from apollo_core.types import Position
    from live_engine.state_store import StateStore

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        with StateStore(db_path) as store:
            # Save a populated Position WITH pending_exit (v1.1 feature)
            pos = Position(
                in_trade=True,
                entry_price=100.0,
                entry_date=pd.Timestamp("2024-03-15"),
                peak_rsi=72.5,
                peak_rsi_price=105.0,
                peak_rsi_date=pd.Timestamp("2024-03-20"),
                peak_close=108.0,
                trail_activation_price=None,
                prev_plus_di=25.0,
                prev_minus_di=15.0,
                cooldown_until=None,
                cooldown_until_date=pd.Timestamp("2024-04-01"),
                pending_exit=True,
                pending_exit_payload={
                    "date": "2024-03-25",
                    "fill_price": 95.0,
                    "primary_reason": "SCORE<50",
                    "pnl_pct": -5.0,
                },
            )
            store.save_position("TEST", pos, last_processed_date=pd.Timestamp("2024-03-25"))

            # Load it back
            loaded, last_proc = store.load_position("TEST")

            assert loaded.in_trade == pos.in_trade
            assert loaded.entry_price == pos.entry_price
            assert loaded.entry_date == pos.entry_date
            assert loaded.peak_rsi == pos.peak_rsi
            assert loaded.peak_rsi_price == pos.peak_rsi_price
            assert loaded.peak_close == pos.peak_close
            assert loaded.cooldown_until_date == pos.cooldown_until_date
            assert last_proc == pd.Timestamp("2024-03-25")
            # v1.1 fields
            assert loaded.pending_exit == True, "pending_exit not preserved"
            assert loaded.pending_exit_payload is not None, "pending_exit_payload not preserved"
            assert loaded.pending_exit_payload["primary_reason"] == "SCORE<50"
            assert loaded.pending_exit_payload["fill_price"] == 95.0

        # Test fresh symbol returns empty Position
        with StateStore(db_path) as store:
            fresh, last_none = store.load_position("NONEXISTENT")
            assert not fresh.in_trade
            assert not fresh.pending_exit
            assert last_none is None

    return "StateStore save/load roundtrip preserves all Position fields (incl. pending_exit)", ""


def test_state_store_alerts():
    """Test 10: StateStore alert log save/list works."""
    from live_engine.state_store import StateStore

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        with StateStore(db_path) as store:
            # Save 3 alerts
            store.save_alert("TEST", pd.Timestamp("2024-01-01"), "ENTRY", "First entry",
                              payload={"score": 75.0})
            store.save_alert("TEST", pd.Timestamp("2024-01-05"), "HOLD", "Hold",
                              payload={"score": 80.0})
            store.save_alert("OTHER", pd.Timestamp("2024-01-03"), "EXIT", "Other symbol exit")

            # List all TEST alerts
            test_alerts = store.list_alerts(symbol="TEST")
            assert len(test_alerts) == 2, f"Expected 2 TEST alerts, got {len(test_alerts)}"

            # List since a date
            recent = store.list_alerts(symbol="TEST", since=pd.Timestamp("2024-01-03"))
            assert len(recent) == 1, f"Expected 1 alert since 2024-01-03, got {len(recent)}"

            # Filter by type
            entries = store.list_alerts(symbol="TEST", alert_type="ENTRY")
            assert len(entries) == 1

            # Count
            assert store.count_alerts("TEST") == 2
            assert store.count_alerts() == 3

    return "StateStore alert log: save/list/count all work correctly", ""


def test_signal_monitor_runs():
    """Test 11: SignalMonitor runs end-to-end on CYIENTDLM without errors."""
    from live_engine.data_replay import BarReplay
    from live_engine.state_store import StateStore
    from live_engine.signal_monitor import SignalMonitor

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        replay = BarReplay(
            data_dir=str(PROJECT_ROOT / "data"),
            symbol="CYIENTDLM",
            start_date="2024-01-01",
            end_date="2024-06-30",
        )
        with StateStore(db_path) as store:
            monitor = SignalMonitor(
                replay=replay,
                state_store=store,
                alert_callback=None,
                exit_mode="NONE",
                auto_confirm_exit=True,
            )
            summary = monitor.run(resume=False, verbose=False)

        assert summary["n_bars_processed"] > 50, f"Expected >50 bars, got {summary['n_bars_processed']}"
        assert summary["n_alerts"] > 0, "Expected at least 1 alert"

    return (f"SignalMonitor ran on CYIENTDLM: "
            f"{summary['n_bars_processed']} bars, "
            f"{summary['n_alerts']} alerts, "
            f"{summary['n_entries']} entries, "
            f"{summary['n_exits']} exits", "")


def test_consistency_vs_backtest():
    """Test 12: CRITICAL — Live monitor decisions match backtest decisions.

    This is the key correctness test. The whole point of the detect/execute
    split was to enable the live monitor to use the SAME detect_exit_triggers()
    function as the backtest. If decisions diverge, the split failed.
    """
    from backtest_engine.backtest import run_stock_backtest
    from live_engine.data_replay import BarReplay
    from live_engine.state_store import StateStore
    from live_engine.signal_monitor import (
        SignalMonitor, ALERT_ENTRY, ALERT_EXIT,
    )

    symbol = "CYIENTDLM"
    start, end = "2024-01-01", "2024-06-30"

    # Backtest baseline
    bt_result = run_stock_backtest(
        data_dir=str(PROJECT_ROOT / "data"),
        symbol=symbol,
        start_date=start,
        end_date=end,
        exit_mode="NONE",
    )
    bt_entries = [e for e in bt_result["trades"] if e["type"] == "ENTRY"]
    bt_exits = [e for e in bt_result["trades"]
                 if e["type"] == "EXIT" and e.get("exit_reason") != "PERIOD_END"]

    # Live monitor
    replay = BarReplay(
        data_dir=str(PROJECT_ROOT / "data"),
        symbol=symbol, start_date=start, end_date=end,
    )
    live_alerts: list[dict] = []
    with tempfile.TemporaryDirectory() as tmpdir:
        with StateStore(Path(tmpdir) / "test.db") as store:
            monitor = SignalMonitor(
                replay=replay, state_store=store,
                alert_callback=lambda a: live_alerts.append(a),
                exit_mode="NONE", auto_confirm_exit=True,
            )
            monitor.run(resume=False, verbose=False)

    live_entries = [a for a in live_alerts if a["alert_type"] == ALERT_ENTRY]
    live_exits = [a for a in live_alerts if a["alert_type"] == ALERT_EXIT]

    assert len(bt_entries) == len(live_entries), \
        f"ENTRY count mismatch: backtest={len(bt_entries)}, live={len(live_entries)}"
    assert len(bt_exits) == len(live_exits), \
        f"EXIT count mismatch: backtest={len(bt_exits)}, live={len(live_exits)}"

    # Compare entry dates
    for i, (b, l) in enumerate(zip(bt_entries, live_entries)):
        bt_date = pd.Timestamp(b["date"])
        live_date = pd.Timestamp(l["timestamp"])
        assert bt_date == live_date, \
            f"ENTRY[{i}] date mismatch: backtest={bt_date}, live={live_date}"

    # Compare exit dates
    for i, (b, l) in enumerate(zip(bt_exits, live_exits)):
        bt_date = pd.Timestamp(b["date"])
        live_date = pd.Timestamp(l["timestamp"])
        assert bt_date == live_date, \
            f"EXIT[{i}] date mismatch: backtest={bt_date}, live={live_date}"

    return (f"Live matches backtest: {len(bt_entries)} entries + "
            f"{len(bt_exits)} exits, all dates identical", "")


def test_resume_after_stop():
    """Test 13: Monitor can stop mid-run, restart, produce identical decisions."""
    from live_engine.data_replay import BarReplay
    from live_engine.state_store import StateStore
    from live_engine.signal_monitor import (
        SignalMonitor, ALERT_ENTRY, ALERT_EXIT,
    )

    symbol = "CYIENTDLM"
    start, end = "2024-01-01", "2024-06-30"

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"

        # Baseline: single run
        replay1 = BarReplay(data_dir=str(PROJECT_ROOT / "data"),
                              symbol=symbol, start_date=start, end_date=end)
        baseline_alerts: list[dict] = []
        with StateStore(db_path) as store:
            m = SignalMonitor(replay=replay1, state_store=store,
                               alert_callback=lambda a: baseline_alerts.append(a),
                               exit_mode="NONE", auto_confirm_exit=True)
            m.run(resume=False, verbose=False)

        # Wipe DB and do split run
        db_path.unlink()
        first_alerts: list[dict] = []
        replay2 = BarReplay(data_dir=str(PROJECT_ROOT / "data"),
                              symbol=symbol, start_date=start, end_date="2024-03-31")
        with StateStore(db_path) as store:
            m = SignalMonitor(replay=replay2, state_store=store,
                               alert_callback=lambda a: first_alerts.append(a),
                               exit_mode="NONE", auto_confirm_exit=True)
            m.run(resume=False, verbose=False)

        # Resume
        resume_alerts: list[dict] = []
        replay3 = BarReplay(data_dir=str(PROJECT_ROOT / "data"),
                              symbol=symbol, start_date=start, end_date=end)
        with StateStore(db_path) as store:
            m = SignalMonitor(replay=replay3, state_store=store,
                               alert_callback=lambda a: resume_alerts.append(a),
                               exit_mode="NONE", auto_confirm_exit=True)
            summary = m.run(resume=True, verbose=False)

        assert summary["n_bars_skipped"] > 0, "Resume should have skipped some bars"
        assert summary["n_bars_processed"] > 0, "Resume should have processed some new bars"

        # Compare decisions (ENTRY + EXIT only, skip STARTUP)
        def decisions(alerts):
            return [(a["alert_type"], str(a["timestamp"]))
                    for a in alerts if a["alert_type"] in (ALERT_ENTRY, ALERT_EXIT)]

        baseline = decisions(baseline_alerts)
        combined = decisions(first_alerts) + decisions(resume_alerts)

        assert len(baseline) == len(combined), \
            f"Decision count mismatch: baseline={len(baseline)}, combined={len(combined)}"
        for i, (b, c) in enumerate(zip(baseline, combined)):
            assert b == c, f"Decision[{i}] mismatch: baseline={b}, combined={c}"

    return (f"Crash-recovery verified: {len(baseline)} decisions match between "
            f"single-run and split-run-with-resume", "")


def test_cli_argparse():
    """Test 14: CLI parser builds without errors and accepts required args."""
    from live_engine.cli import build_parser
    parser = build_parser()
    # Parse a minimal arg list
    args = parser.parse_args(["--symbol", "CYIENTDLM", "--data-dir", "data"])
    assert args.symbol == "CYIENTDLM"
    assert args.data_dir == "data"
    assert args.exit_mode == "NONE"  # default
    assert args.no_resume is False  # default
    return "CLI parser builds and parses args correctly", ""


def test_bat_file_path():
    """Test 15: run_apollo_live.bat exists and is well-formed."""
    bat_path = PROJECT_ROOT / "run_apollo_live.bat"
    assert bat_path.exists(), "run_apollo_live.bat not found"
    content = bat_path.read_text(encoding="utf-8", errors="ignore")
    # Must reference streamlit or python -m live_engine
    assert ("streamlit" in content.lower()
            or "python -m live_engine" in content.lower()
            or "python live_engine" in content.lower()), \
        "run_apollo_live.bat does not reference streamlit or python -m live_engine"
    return "run_apollo_live.bat exists and references the live engine", ""


# =========================================================================
# v1.1 — New tests for dashboard + human-confirm exit flow
# =========================================================================

def test_dashboard_imports():
    """Test 16: dashboard.py imports cleanly (Streamlit + plotly optional)."""
    # We can't actually run streamlit in preflight, but we can import the module
    # and verify its main() function exists.
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "dashboard", PROJECT_ROOT / "live_engine" / "dashboard.py"
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    assert hasattr(mod, "main"), "dashboard.py missing main()"
    assert hasattr(mod, "TEST_STOCKS"), "dashboard.py missing TEST_STOCKS"
    assert hasattr(mod, "load_score_history"), "dashboard.py missing load_score_history"
    assert hasattr(mod, "confirm_exit"), "dashboard.py should re-export confirm_exit"
    assert "CYIENTDLM" in mod.TEST_STOCKS
    return "dashboard.py imports cleanly with all expected symbols", ""


def test_run_live_imports():
    """Test 17: run_live.py launcher imports cleanly and has main()."""
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "run_live", PROJECT_ROOT / "live_engine" / "run_live.py"
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    assert hasattr(mod, "main"), "run_live.py missing main()"
    assert hasattr(mod, "_check_project_structure"), "run_live.py missing _check_project_structure"
    # Verify it can detect missing files
    missing = mod._check_project_structure()
    assert missing == [], f"run_live.py detected missing files: {missing}"
    return "run_live.py imports cleanly and structure check passes", ""


def test_human_confirm_mode_sets_pending_exit():
    """Test 18: CRITICAL — auto_confirm_exit=False sets pending_exit (no reset)."""
    from live_engine.data_replay import BarReplay
    from live_engine.state_store import StateStore
    from live_engine.signal_monitor import (
        SignalMonitor, ALERT_EXIT, ALERT_HOLD,
    )

    symbol = "CYIENTDLM"
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        replay = BarReplay(
            data_dir=str(PROJECT_ROOT / "data"),
            symbol=symbol, start_date="2024-01-01", end_date="2024-06-30",
        )
        alerts = []
        with StateStore(db_path) as store:
            monitor = SignalMonitor(
                replay=replay, state_store=store,
                alert_callback=lambda a: alerts.append(a),
                exit_mode="NONE",
                auto_confirm_exit=False,  # KEY: human-confirm mode
            )
            monitor.run(resume=False, verbose=False)

            exit_alerts = [a for a in alerts if a["alert_type"] == ALERT_EXIT]
            assert len(exit_alerts) >= 1, "Expected ≥1 EXIT alert in this date range"

            # After running, the position should have pending_exit=True
            # (the last EXIT alert hasn't been confirmed)
            pos, _ = store.load_position(symbol)
            assert pos.pending_exit, \
                f"pending_exit should be True after EXIT alert (got {pos.pending_exit})"
            assert pos.pending_exit_payload is not None, \
                "pending_exit_payload should be populated"
            assert "primary_reason" in pos.pending_exit_payload

            # Should still be in_trade (not auto-reset)
            assert pos.in_trade, "in_trade should still be True (no auto-reset)"

    return (f"Human-confirm mode: {len(exit_alerts)} EXIT alert(s) fired, "
            f"pending_exit=True, position NOT auto-reset", "")


def test_confirm_exit_resets_position():
    """Test 19: confirm_exit() resets position + emits EXIT_CONFIRMED alert."""
    from live_engine.data_replay import BarReplay
    from live_engine.state_store import StateStore
    from live_engine.signal_monitor import (
        SignalMonitor, confirm_exit, ALERT_EXIT_CONFIRMED,
    )
    from backtest_engine.eod2_loader import load_eod2_stock
    from apollo_core.constants import DIVERGENCE_COOLDOWN

    symbol = "CYIENTDLM"
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        replay = BarReplay(
            data_dir=str(PROJECT_ROOT / "data"),
            symbol=symbol, start_date="2024-01-01", end_date="2024-06-30",
        )
        with StateStore(db_path) as store:
            monitor = SignalMonitor(
                replay=replay, state_store=store, alert_callback=None,
                exit_mode="NONE", auto_confirm_exit=False,
            )
            monitor.run(resume=False, verbose=False)

            pos_before, _ = store.load_position(symbol)
            if not pos_before.pending_exit:
                return "SKIP — no pending exit in this range", ""

            df_d, _, _ = load_eod2_stock(str(PROJECT_ROOT / "data"), symbol)
            ok = confirm_exit(
                state_store=store, symbol=symbol, df_d=df_d,
                divergence_cooldown_days=DIVERGENCE_COOLDOWN,
            )
            assert ok, "confirm_exit returned False but pending_exit was True"

            pos_after, _ = store.load_position(symbol)
            assert not pos_after.in_trade, "in_trade should be False after confirm"
            assert not pos_after.pending_exit, "pending_exit should be False after confirm"
            assert pos_after.cooldown_until_date is not None, \
                "cooldown_until_date should be set after confirm"

            confirmed = store.list_alerts(symbol=symbol, alert_type=ALERT_EXIT_CONFIRMED)
            assert len(confirmed) >= 1, "No EXIT_CONFIRMED alert emitted"

    return "confirm_exit() correctly resets position + emits EXIT_CONFIRMED", ""


def test_dismiss_exit_keeps_position_open():
    """Test 20: dismiss_exit() clears pending but keeps position open."""
    from live_engine.data_replay import BarReplay
    from live_engine.state_store import StateStore
    from live_engine.signal_monitor import (
        SignalMonitor, dismiss_exit, ALERT_EXIT_DISMISSED,
    )

    symbol = "CYIENTDLM"
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        replay = BarReplay(
            data_dir=str(PROJECT_ROOT / "data"),
            symbol=symbol, start_date="2024-01-01", end_date="2024-06-30",
        )
        with StateStore(db_path) as store:
            monitor = SignalMonitor(
                replay=replay, state_store=store, alert_callback=None,
                exit_mode="NONE", auto_confirm_exit=False,
            )
            monitor.run(resume=False, verbose=False)

            pos_before, _ = store.load_position(symbol)
            if not pos_before.pending_exit:
                return "SKIP — no pending exit", ""

            entry_price_before = pos_before.entry_price
            ok = dismiss_exit(state_store=store, symbol=symbol)
            assert ok, "dismiss_exit returned False but pending was True"

            pos_after, _ = store.load_position(symbol)
            assert pos_after.in_trade, "in_trade should still be True after dismiss"
            assert not pos_after.pending_exit, "pending_exit should be False after dismiss"
            assert pos_after.entry_price == entry_price_before, \
                "entry_price should be unchanged after dismiss"

            dismissed = store.list_alerts(symbol=symbol, alert_type=ALERT_EXIT_DISMISSED)
            assert len(dismissed) >= 1, "No EXIT_DISMISSED alert emitted"

    return "dismiss_exit() keeps position open, clears pending", ""


def test_legacy_v1_0_db_migration():
    """Test 21: v1.0 SQLite DB (without pending_exit columns) auto-migrates on open."""
    import sqlite3
    from live_engine.state_store import StateStore
    from apollo_core.types import Position

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "legacy.db"
        # Create a v1.0-style schema (no pending_exit columns)
        conn = sqlite3.connect(str(db_path))
        conn.executescript("""
            CREATE TABLE monitor_state (
                symbol                   TEXT PRIMARY KEY,
                last_processed_date      TEXT,
                in_trade                 INTEGER NOT NULL DEFAULT 0,
                entry_price              REAL,
                entry_date               TEXT,
                peak_rsi                 REAL,
                peak_rsi_price           REAL,
                peak_rsi_date            TEXT,
                peak_close               REAL,
                trail_activation_price   REAL,
                prev_plus_di             REAL,
                prev_minus_di            REAL,
                cooldown_until           INTEGER,
                cooldown_until_date      TEXT,
                updated_at               TEXT NOT NULL
            );
            CREATE TABLE alerts (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol      TEXT NOT NULL,
                timestamp   TEXT NOT NULL,
                alert_type  TEXT NOT NULL,
                message     TEXT NOT NULL,
                payload_json TEXT,
                created_at  TEXT NOT NULL DEFAULT (datetime('now'))
            );
        """)
        # Insert a v1.0-style row
        conn.execute(
            "INSERT INTO monitor_state (symbol, in_trade, entry_price, updated_at) "
            "VALUES (?, ?, ?, ?)",
            ("LEGACY", 1, 100.0, "2024-01-01T00:00:00"),
        )
        conn.commit()
        conn.close()

        # Open with StateStore — should auto-migrate
        with StateStore(db_path) as store:
            pos, _ = store.load_position("LEGACY")
            assert pos.in_trade, "Legacy position not loaded"
            assert pos.entry_price == 100.0
            assert pos.pending_exit == False, \
                "pending_exit should default to False on migrated DB"
            assert pos.pending_exit_payload is None

            # Should be able to save back (with new fields populated)
            pos.pending_exit = True
            pos.pending_exit_payload = {"reason": "test"}
            store.save_position("LEGACY", pos)

            pos2, _ = store.load_position("LEGACY")
            assert pos2.pending_exit == True
            assert pos2.pending_exit_payload == {"reason": "test"}

    return "v1.0 DB auto-migrates to v1.1 schema on open", ""


# =========================================================================
# v1.4 tests — AlertManager, DailyReport, RunHeadless, LiveFeed
# =========================================================================


def test_alert_manager_file_log():
    """Test 22: AlertManager writes JSONL alerts to reports/alerts.log."""
    import json
    from live_engine.alert_manager import AlertManager

    with tempfile.TemporaryDirectory() as tmpdir:
        am = AlertManager(
            log_dir=tmpdir,
            enable_telegram=False,  # no env vars → file-only
            enable_async=False,
            verbose=False,
        )
        am.start()
        am.send_alert({
            "timestamp": pd.Timestamp("2026-07-27T10:15:00"),
            "alert_type": "ENTRY",
            "message": "Test entry alert",
            "payload": {"price": 540.20, "score": 68.5},
        }, "CYIENTDLM")
        am.send_alert({
            "timestamp": pd.Timestamp("2026-07-27T10:16:00"),
            "alert_type": "HOLD",
            "message": "HOLD test",
            "payload": {},
        }, "CYIENTDLM")
        am.shutdown()

        log_path = Path(tmpdir) / "alerts.log"
        assert log_path.exists(), f"alerts.log not created at {log_path}"

        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 2, f"Expected 2 log lines, got {len(lines)}"

        # Verify JSONL is parseable
        for line in lines:
            entry = json.loads(line)
            assert "timestamp" in entry
            assert "symbol" in entry
            assert "alert_type" in entry
            assert "message" in entry
            assert "payload" in entry

        # Verify Telegram is reported as disabled
        assert not am.telegram_enabled, "Telegram should be disabled (no env vars)"
    return "AlertManager file-log writes 2 JSONL lines correctly", ""


def test_alert_manager_fail_soft():
    """Test 23: AlertManager does not raise on backend errors."""
    from live_engine.alert_manager import AlertManager

    with tempfile.TemporaryDirectory() as tmpdir:
        am = AlertManager(
            log_dir=tmpdir,
            enable_telegram=False,
            enable_async=False,
            verbose=False,
        )
        am.start()

        # Send an alert with a malformed timestamp (would break JSON serialization
        # if not for default=str in json.dumps). The manager should not raise.
        am.send_alert({
            "timestamp": "not-a-timestamp",
            "alert_type": "ENTRY",
            "message": "Malformed test",
            "payload": {"weird": object()},  # non-serializable
        }, "TEST")

        am.shutdown()
    return "AlertManager fail-soft: malformed alert did not raise", ""


def test_daily_report_generates_files():
    """Test 24: daily_report.generate_report() produces MD + 2 CSVs."""
    import json
    from live_engine.daily_report import generate_report
    from live_engine.state_store import StateStore
    from apollo_core.types import Position
    import pandas as pd
    from datetime import date

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        reports_dir = Path(tmpdir) / "reports"
        data_dir = PROJECT_ROOT / "data"
        watchlist_path = PROJECT_ROOT / "my_watchlist.json"

        # Seed the DB with an alert for the target date
        with StateStore(db_path) as store:
            store.save_position("CYIENTDLM", Position(in_trade=True, entry_price=436.55,
                                                     entry_date=pd.Timestamp("2026-06-10")),
                                last_processed_date=pd.Timestamp("2026-07-24"))
            store.save_alert(
                symbol="CYIENTDLM",
                timestamp=pd.Timestamp("2026-07-24"),
                alert_type="ENTRY",
                message="Test entry for daily report",
                payload={"score": 70.0},
            )

        result = generate_report(
            db_path=str(db_path),
            watchlist_path=str(watchlist_path),
            data_dir=str(data_dir),
            target_date=date(2026, 7, 24),
            reports_dir=str(reports_dir),
            push_telegram=False,
            verbose=False,
        )

        # Verify all 3 files exist
        assert Path(result["md_path"]).exists(), f"MD not created: {result['md_path']}"
        assert Path(result["csv_alerts_path"]).exists(), f"CSV alerts not created"
        assert Path(result["csv_rankings_path"]).exists(), f"CSV rankings not created"

        # Verify MD contains expected sections
        md = Path(result["md_path"]).read_text(encoding="utf-8")
        assert "Apollo Live — Daily Report" in md
        assert "2026-07-24" in md
        assert "Alerts Fired" in md
        assert "Open Positions" in md
        assert "Top 10 Watchlist" in md
        assert "CYIENTDLM" in md

        # Verify CSV alerts has the seeded alert
        csv_text = Path(result["csv_alerts_path"]).read_text(encoding="utf-8")
        assert "ENTRY" in csv_text
        assert "CYIENTDLM" in csv_text

        # Verify rankings CSV has CYIENTDLM
        rankings_text = Path(result["csv_rankings_path"]).read_text(encoding="utf-8")
        assert "CYIENTDLM" in rankings_text

        # Verify return dict
        assert result["n_alerts"] >= 1
        assert result["n_rankings"] >= 1
        assert result["n_open_positions"] >= 1
        assert result["telegram_pushed"] is False  # we passed push_telegram=False
    return "Daily report generates MD + 2 CSVs with expected content", ""


def test_live_feed_protocol():
    """Test 25: LiveFeed protocol — BarReplayFeed works, KiteLiveFeed raises NotImplementedError."""
    from live_engine.live_feed import BarReplayFeed, KiteLiveFeed, make_feed, LiveFeed

    # Build a CSV-backed feed
    feed = make_feed(
        source="csv",
        symbol="CYIENTDLM",
        data_dir=str(PROJECT_ROOT / "data"),
        start_date="2024-01-01",
        end_date="2026-07-27",
    )
    assert isinstance(feed, BarReplayFeed)
    assert feed.symbol == "CYIENTDLM"
    assert feed.source == "csv-replay"
    assert feed.n_bars > 0, "BarReplayFeed should have > 0 bars for CYIENTDLM"

    # Verify it satisfies the LiveFeed protocol (structural typing)
    assert isinstance(feed, LiveFeed), "BarReplayFeed should satisfy LiveFeed protocol"

    # Pull a bar via next_bar()
    bar = feed.next_bar()
    assert bar is not None, "next_bar() should return a bar before exhaustion"
    assert hasattr(bar, "daily_result"), "Bar should have daily_result attr"
    assert "total" in bar.daily_result, "daily_result should have 'total' (score)"

    # KiteLiveFeed should raise NotImplementedError (stub)
    try:
        KiteLiveFeed(symbol="CYIENTDLM")
        assert False, "KiteLiveFeed should have raised NotImplementedError"
    except NotImplementedError:
        pass  # expected

    # make_feed with unknown source should raise ValueError
    try:
        make_feed(source="bogus", symbol="X")
        assert False, "make_feed should have raised ValueError"
    except ValueError:
        pass

    feed.close()
    return "LiveFeed protocol: BarReplayFeed works, KiteLiveFeed + bad source raise", ""


def test_multi_monitor_resume_false_bugfix():
    """Test 26: v1.4 bugfix — MultiStockMonitor no longer crashes on resume=False.

    v1.3 had a bug: `type(monitor._position)()` returned None because
    _position was None at that point. v1.4 uses explicit Position().
    """
    from live_engine.multi_monitor import MultiStockMonitor
    from live_engine.state_store import StateStore

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        monitor = MultiStockMonitor(
            symbols=["CYIENTDLM"],
            data_dir=str(PROJECT_ROOT / "data"),
            start_date="2024-01-01",
            end_date="2026-07-27",
            db_path=str(db_path),
            pace_seconds=0.0,
            exit_mode="NONE",
            auto_confirm_exit=True,
            alert_callback=None,
            resume=False,  # ← this used to crash
            verbose=False,
        )
        summary = monitor.run()
        assert summary["n_symbols"] == 1
        assert summary["total_bars"] > 0
        assert summary["total_entries"] > 0
        assert summary["total_exits"] > 0

        # Verify state persisted
        with StateStore(str(db_path)) as store:
            syms = store.list_monitored_symbols()
            assert "CYIENTDLM" in syms
    return "v1.4 bugfix verified: MultiStockMonitor(resume=False) works", ""


def test_run_headless_argparse():
    """Test 27: run_headless.build_parser() builds and parses args correctly."""
    from live_engine.run_headless import build_parser

    p = build_parser()
    # Multi-stock mode
    args = p.parse_args(["--watchlist", "my_watchlist.json", "--pace-seconds", "5.0"])
    assert args.watchlist == "my_watchlist.json"
    assert args.pace_seconds == 5.0
    assert args.symbol is None
    assert args.exit_mode == "NONE"
    assert args.auto_confirm is False
    assert args.no_telegram is False

    # Single-stock mode
    args = p.parse_args(["--symbol", "CYIENTDLM", "--quiet"])
    assert args.symbol == "CYIENTDLM"
    assert args.quiet is True

    # --once flag (instant mode)
    args = p.parse_args(["--symbol", "CYIENTDLM", "--once"])
    assert args.once is True

    # --no-telegram
    args = p.parse_args(["--symbol", "CYIENTDLM", "--no-telegram"])
    assert args.no_telegram is True
    return "run_headless argparse parses multi/single/once/no-telegram flags", ""




def main():
    print("=" * 70)
    print(f"  APOLLO LIVE {CURRENT_VERSION} — PRE-FLIGHT TEST SUITE")
    print("=" * 70)
    print(f"  Project root: {PROJECT_ROOT}")
    print(f"  Python: {sys.version.split()[0]}")
    print("=" * 70)
    print()

    run_test("1. Syntax check all .py files", test_syntax_all_files)
    run_test("2. __future__ import ordering", test_future_import_ordering)
    run_test("3. Import all modules", test_import_all_modules)
    run_test("4. All required files present", test_required_files_present)
    run_test("5. requirements.txt valid", test_requirements_file)
    run_test(f"6. Version string consistency ({CURRENT_VERSION})", test_version_consistency)
    run_test("7. CHANGELOG.md at project root", test_changelog_in_zip_root)
    run_test("8. BarReplay loads CYIENTDLM", test_data_replay_loads_cyientdlm)
    run_test("9. StateStore save/load roundtrip (incl. pending_exit)", test_state_store_roundtrip)
    run_test("10. StateStore alert log", test_state_store_alerts)
    run_test("11. SignalMonitor runs end-to-end", test_signal_monitor_runs)
    run_test("12. CRITICAL: Live decisions match backtest", test_consistency_vs_backtest)
    run_test("13. Crash-recovery (resume after stop)", test_resume_after_stop)
    run_test("14. CLI argparse", test_cli_argparse)
    run_test("15. run_apollo_live.bat correctness", test_bat_file_path)
    run_test("16. dashboard.py imports cleanly", test_dashboard_imports)
    run_test("17. run_live.py launcher imports cleanly", test_run_live_imports)
    run_test("18. CRITICAL: Human-confirm mode sets pending_exit", test_human_confirm_mode_sets_pending_exit)
    run_test("19. confirm_exit() resets position", test_confirm_exit_resets_position)
    run_test("20. dismiss_exit() keeps position open", test_dismiss_exit_keeps_position_open)
    run_test("21. v1.0 DB auto-migrates to v1.1", test_legacy_v1_0_db_migration)

    # v1.4 additions
    run_test("22. AlertManager writes JSONL to file log", test_alert_manager_file_log)
    run_test("23. AlertManager fail-soft on malformed alerts", test_alert_manager_fail_soft)
    run_test("24. DailyReport generates MD + 2 CSVs", test_daily_report_generates_files)
    run_test("25. LiveFeed protocol + KiteLiveFeed stub", test_live_feed_protocol)
    run_test("26. v1.4 bugfix: MultiStockMonitor resume=False", test_multi_monitor_resume_false_bugfix)
    run_test("27. run_headless argparse", test_run_headless_argparse)

    print()
    print("=" * 70)
    passed = sum(1 for r in results if r.passed)
    failed = sum(1 for r in results if not r.passed)
    print(f"  RESULT: {passed} passed, {failed} failed, {len(results)} total")
    print("=" * 70)

    if failed > 0:
        print()
        print("*** ONE OR MORE TESTS FAILED — ZIP IS NOT SHIPPABLE ***")
        print()
        print("Failed tests:")
        for r in results:
            if not r.passed:
                print(f"  - {r.name}: {r.message}")
        return 1

    print()
    print("*** ALL TESTS PASSED — ZIP IS SHIPPABLE ***")
    return 0


if __name__ == "__main__":
    sys.exit(main())
