"""Convert chartink-format CSV to eod2-format CSV.

chartink format: "Sun Jul 09 2023 00:00:00 GMT+0530 (India Standard Time)"
eod2 format:     "2023-07-09"
"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from datetime import datetime

import pandas as pd

CHARTINK_RE = re.compile(r"\s*\(.*\)\s*$")  # strip "(India Standard Time)" suffix


def convert(in_path: str, out_path: str) -> int:
    df = pd.read_csv(in_path)
    if "Date" not in df.columns:
        print(f"ERROR: 'Date' column not found in {in_path}", file=sys.stderr)
        return 1

    # Strip "(India Standard Time)" suffix from each date string
    raw_dates = df["Date"].astype(str).str.replace(CHARTINK_RE, "", regex=True)

    # Parse with chartink's format
    parsed = pd.to_datetime(raw_dates, format="%a %b %d %Y %H:%M:%S GMT%z", errors="coerce")

    # Fall back to dateutil for any that failed
    if parsed.isna().any():
        fallback = pd.to_datetime(raw_dates, errors="coerce", utc=True)
        parsed = parsed.fillna(fallback)

    if parsed.isna().any():
        n_failed = parsed.isna().sum()
        print(f"WARNING: {n_failed} dates could not be parsed", file=sys.stderr)

    # Convert to eod2's expected format: YYYY-MM-DD (no timezone, no time)
    df["Date"] = parsed.dt.tz_convert("Asia/Kolkata").dt.strftime("%Y-%m-%d")

    df.to_csv(out_path, index=False)
    print(f"Converted {len(df)} rows: {in_path} -> {out_path}")
    print(f"  First date: {df['Date'].iloc[0]}")
    print(f"  Last date:  {df['Date'].iloc[-1]}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <input.csv> <output.csv>", file=sys.stderr)
        sys.exit(2)
    sys.exit(convert(sys.argv[1], sys.argv[2]))
