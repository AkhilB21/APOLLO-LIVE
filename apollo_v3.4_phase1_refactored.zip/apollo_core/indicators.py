"""
Core Technical Indicators for the Apollo Analysis Engine.

Indicators implemented:
  - RSI (Relative Strength Index): periods 21, 36, 56
  - TP28: 28-period Simple Moving Average of Typical Price (H+L+C)/3
  - WC50: 50-period Simple Moving Average of Weighted Close (H+L+2C)/4

All functions accept a pandas DataFrame with columns: high, low, close, volume
and return the computed series, aligned to the input index.
"""

import numpy as np
import pandas as pd


def compute_rsi(close: pd.Series, period: int) -> pd.Series:
    """
    Compute RSI using Wilder's smoothing method.

    Parameters
    ----------
    close : pd.Series
        Close price series.
    period : int
        RSI lookback period (e.g., 21, 36, 56).

    Returns
    -------
    pd.Series
        RSI values aligned to the input index. First `period` values are NaN.
    """
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)

    # Wilder's exponential moving average (alpha = 1/period)
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()

    # Natural division: loss=0 → rs=inf → RSI=100 (strong uptrend).
    # Both zero → rs=NaN → RSI=NaN (flat line, RSI undefined).
    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return rsi


def compute_tp28(df: pd.DataFrame, period: int = 28) -> pd.Series:
    """
    Compute TP28: Simple Moving Average of Typical Price over `period` bars.

    Typical Price (TP) = (High + Low + Close) / 3
    TP28 = SMA(TP, 28)

    Parameters
    ----------
    df : pd.DataFrame
        OHLC data with columns: high, low, close.
    period : int
        SMA window for TP. Default is 28.

    Returns
    -------
    pd.Series
        TP28 values aligned to the input index.
    """
    tp = (df["high"] + df["low"] + df["close"]) / 3.0
    return tp.rolling(window=period, min_periods=period).mean()


def compute_wc(df: pd.DataFrame, period: int) -> pd.Series:
    """
    Compute SMA of Weighted Close (WC) over `period` bars.

    Weighted Close (WC) = (High + Low + 2*Close) / 4
    """
    wc = (df["high"] + df["low"] + 2.0 * df["close"]) / 4.0
    return wc.rolling(window=period, min_periods=period).mean()


def compute_wc50(df: pd.DataFrame, period: int = 50) -> pd.Series:
    """
    Compute WC50: Simple Moving Average of Weighted Close over `period` bars.

    Weighted Close (WC) = (High + Low + 2 * Close) / 4
    WC50 = SMA(WC, 50)

    Parameters
    ----------
    df : pd.DataFrame
        OHLC data with columns: high, low, close.
    period : int
        SMA window for WC. Default is 50.

    Returns
    -------
    pd.Series
        WC50 values aligned to the input index.
    """
    return compute_wc(df, period)


def compute_wc21(df: pd.DataFrame) -> pd.Series:
    """
    Compute WC21: 21-period SMA of Weighted Close.

    Added in v3 to support the B6 (WC21 Proximity) signal which previously
    relied on a pre-computed column in the input CSV.
    """
    return compute_wc(df, 21)


def detect_trough_rsi(
    rsi: pd.Series, rsi_threshold: float, window: int
) -> pd.Series:
    """
    Detect bars where RSI is at a local minimum within a centered window.

    A trough is identified when:
      1. RSI <= rsi_threshold at the current bar, AND
      2. RSI at the current bar is the minimum within `window` bars
         (window//2 bars on each side).

    Parameters
    ----------
    rsi : pd.Series
        RSI series.
    rsi_threshold : float
        Maximum RSI value to qualify as a trough (e.g., 40 for Daily, 38 for 4H).
    window : int
        Total window size for local minimum check (e.g., 11 for Daily, 5 for 4H).

    Returns
    -------
    pd.Series
        Boolean series: True where a trough is detected.
    """
    half = window // 2
    rolling_min = rsi.rolling(window=window, center=True, min_periods=window).min()
    is_trough = (rsi <= rsi_threshold) & (rsi == rolling_min)
    return is_trough.fillna(False)


def compute_adx(df: pd.DataFrame, period: int = 14):
    """
    Compute ADX, +DI, -DI using Wilder's smoothing method.

    Parameters
    ----------
    df : pd.DataFrame
        OHLC data with columns: high, low, close.
    period : int
        ADX lookback period (default 14).

    Returns
    -------
    tuple of (plus_di, minus_di, adx) as pd.Series.
    """
    high = df["high"]
    low = df["low"]
    close = df["close"]

    prev_high = high.shift(1)
    prev_low = low.shift(1)
    prev_close = close.shift(1)

    # True Range
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    # Directional Movement
    up_move = high - prev_high
    down_move = prev_low - low

    plus_dm = pd.Series(0.0, index=df.index, dtype=float)
    minus_dm = pd.Series(0.0, index=df.index, dtype=float)
    plus_dm = up_move.copy()
    minus_dm = down_move.copy()
    plus_dm[(up_move < down_move) | (up_move < 0)] = 0.0
    minus_dm[(down_move < up_move) | (down_move < 0)] = 0.0

    # Wilder's smoothing
    atr = tr.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    smooth_plus = plus_dm.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    smooth_minus = minus_dm.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()

    plus_di = 100.0 * smooth_plus / atr
    minus_di = 100.0 * smooth_minus / atr

    dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    adx = dx.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()

    return plus_di, minus_di, adx


def compute_macd(close: pd.Series, fast: int = 12, slow: int = 26,
                  signal_period: int = 9):
    """
    Compute MACD line, Signal line, and Histogram.

    Parameters
    ----------
    close : pd.Series
        Close price series.
    fast : int
        Fast EMA period (default 12).
    slow : int
        Slow EMA period (default 26).
    signal_period : int
        Signal line EMA period (default 9).

    Returns
    -------
    tuple of (macd_line, signal_line, histogram) as pd.Series.
    """
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


# ---------------------------------------------------------------------------
# Unified indicator computation (added in v3)
# ---------------------------------------------------------------------------

APOLLO_INDICATOR_SPEC = {
    # column_name: (function, args)
    "RSI rsi (21,C)":      ("rsi",    {"period": 21}),
    "RSI rsi (56)":        ("rsi",    {"period": 56}),
    "RSI rsi (36)":        ("rsi",    {"period": 36}),
    "Result Typical Price (28,n)": ("tp",  {"period": 28}),
    "Result Weighted Close (50,y)": ("wc", {"period": 50}),
    "Result Weighted Close (21)":   ("wc", {"period": 21}),
    "+DI ADX (14,14,y,n)":  ("plus_di",  {"period": 14}),
    "-DI ADX (14,14,y,n)":  ("minus_di", {"period": 14}),
    "ADX ADX (14,14,y,n)":  ("adx",      {"period": 14}),
    "MACD macd (12,26,9)":  ("macd_line", {"fast": 12, "slow": 26, "signal_period": 9}),
    "Signal macd (12,26,9)": ("macd_signal", {"fast": 12, "slow": 26, "signal_period": 9}),
    "macd (12,26,9)_hist":   ("macd_hist",   {"fast": 12, "slow": 26, "signal_period": 9}),
}


def compute_all_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the full Apollo indicator set from a raw OHLCV DataFrame.

    Returns
    -------
    pd.DataFrame
        Original OHLCV columns plus Apollo-named indicator columns.
        All values are numeric (float); indicator warmup rows are NaN.

    Notes
    -----
    - RSI/ADX use Wilder smoothing (alpha = 1/period, min_periods=period).
    - TP28/WC21/WC50 are simple SMAs.
    - MACD uses standard EMA(fast) - EMA(slow), signal = EMA(9) of MACD line.

    Formulas match the schema used by ChartAlert / Spider ChartLink exports
    that the Apollo engine was originally written to consume.
    """
    out = df.copy()

    # Pre-compute each indicator family once
    rsi21 = compute_rsi(out["close"], 21)
    rsi36 = compute_rsi(out["close"], 36)
    rsi56 = compute_rsi(out["close"], 56)
    tp28  = compute_tp28(out, 28)
    wc50  = compute_wc(out, 50)
    wc21  = compute_wc(out, 21)
    plus_di, minus_di, adx = compute_adx(out, 14)
    macd_line, macd_signal, macd_hist = compute_macd(
        out["close"], fast=12, slow=26, signal_period=9
    )

    out["RSI rsi (21,C)"] = rsi21
    out["RSI rsi (56)"] = rsi56
    out["RSI rsi (36)"] = rsi36
    out["Result Typical Price (28,n)"] = tp28
    out["Result Weighted Close (50,y)"] = wc50
    out["Result Weighted Close (21)"] = wc21
    out["+DI ADX (14,14,y,n)"] = plus_di
    out["-DI ADX (14,14,y,n)"] = minus_di
    out["ADX ADX (14,14,y,n)"] = adx
    out["MACD macd (12,26,9)"] = macd_line
    out["Signal macd (12,26,9)"] = macd_signal
    out["macd (12,26,9)_hist"] = macd_hist

    return out


def get_indicator_provenance(df: pd.DataFrame) -> dict:
    """
    Walk a DataFrame and tag each Apollo-required indicator column as
    'pre_supplied' or 'computed'. Used by the report's Data Provenance row
    (charter rule 7).
    """
    provenance = {}
    for col in APOLLO_INDICATOR_SPEC:
        provenance[col] = "pre_supplied" if col in df.columns else "computed"
    return provenance