
"""Apollo Core — Type Definitions.
Dataclasses shared across backtest_engine and (future) live_engine.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TradeEvent:
    """A single completed round-trip trade (entry -> exit)."""
    symbol: str
    entry_date: str
    entry_price: float
    exit_date: str
    exit_price: float
    direction: str                    # "LONG" (or future "SHORT")
    exit_reason: str                  # e.g. "SL Hit", "Target Hit", "RSI Divergence"
    quantity: float = 1.0
    pnl: float = 0.0                  # absolute P&L
    pnl_pct: float = 0.0              # percentage P&L
    holding_days: int = 0
    raw_score: float = 0.0            # entry score
    bucket: str = ""                  # bucket label at entry
    bucket_multiplier: float = 1.0    # multiplier at entry (recorded, not applied in V3.3+)
    ignored_exits: list = field(default_factory=list)  # exits user ignored in live mode


@dataclass
class DailyResult:
    """Per-day signal evaluation result for one stock."""
    date: str
    symbol: str
    raw_score: float
    total_score: float                # = raw_score (bucket decoupled in V3.3+)
    bucket: str = ""
    bucket_multiplier: float = 1.0
    entry_signal: bool = False        # score >= ENTRY_THRESHOLD
    trough_pos: str = ""              # e.g. "0 / 5"
    signals_hit: list = field(default_factory=list)  # which of the 21 signals fired
    ipo_signals_hit: list = field(default_factory=list)


@dataclass
class SignalResult:
    """Result of evaluating all 21 (+ 12 IPO) signals for one bar."""
    date: str
    symbol: str
    raw_total: float                  # sum of all signal weights
    signal_details: dict = field(default_factory=dict)   # {signal_name: weight or 0}
    ipo_raw_total: float = 0.0
    ipo_signal_details: dict = field(default_factory=dict)
    is_ipo_period: bool = False
    weekly_rsi: float = 0.0
    adx: float = 0.0
    atr: float = 0.0
    rsi: float = 0.0
