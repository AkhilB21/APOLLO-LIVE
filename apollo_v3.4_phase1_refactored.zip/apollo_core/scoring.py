"""Apollo Core — Scoring Module

Pure computation functions for signal evaluation, scoring, and classification.
Extracted from backtest.py (V3.3) with no I/O dependencies.

Functions:
    _graded                  — linear interpolation in buffer zone
    classify_score           — map total score -> (action, position_pct)
    detect_troughs           — boolean series of RSI troughs
    get_latest_trough_pos    — most recent trough on or before index
    compute_weekly_rsi       — Wilder RSI on weekly close
    eval_signals             — evaluate all 21 signals at one daily bar
    eval_ipo_signals         — evaluate all 12 IPO signals at one daily bar
    _normalize_ipo_score     — map IPO raw (0-69) to 0-100
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from apollo_core.constants import (
    ENTRY_THRESHOLD,
    EXIT_THRESHOLD,
    DIVERGENCE_RSI_DROP,
    DIVERGENCE_COOLDOWN,
    SIGNAL_DEFS,
    POOL_ORDER,
    POOL_MAX,
    POOL_NAMES,
    POOL_DESC,
    IPO_SIGNAL_DEFS,
    IPO_POOL_ORDER,
    IPO_POOL_MAX,
    IPO_POOL_NAMES,
    DEFAULT_MIN_TRADING_DAYS,
)
from apollo_core.indicators import compute_all_indicators


def _graded(value: float, max_pts: float, buf_lo: float, buf_hi: float) -> float:
    """Linear interpolation in buffer zone.

    Returns *max_pts* when ``value >= buf_hi``, 0.0 when ``value <= buf_lo``,
    and a linear ramp in between.  NaN → 0.0.
    """
    if np.isnan(value):
        return 0.0
    if value >= buf_hi:
        return float(max_pts)
    if value <= buf_lo:
        return 0.0
    ratio = (value - buf_lo) / (buf_hi - buf_lo)
    return round(max_pts * ratio, 2)

def classify_score(score: float) -> tuple[str, str]:
    """Map total score to (action_label, position_pct_string)."""
    if score >= 90:
        return "FULL STRONG", "100%"
    elif score >= 80:
        return "FULL ENTRY", "100%"
    elif score >= 70:
        return "STANDARD", "60-70%"
    elif score >= 50:
        return "WATCHLIST", "0%"
    else:
        return "DO NOT ENTER", "0%"

def detect_troughs(rsi: pd.Series, threshold: float, window: int) -> pd.Series:
    """Detect RSI troughs: RSI <= threshold AND local minimum in centered window."""
    rolling_min = rsi.rolling(window=window, center=True, min_periods=window).min()
    is_trough = (rsi <= threshold) & (rsi == rolling_min)
    return is_trough.fillna(False)

def get_latest_trough_pos(trough_series: pd.Series, idx: int) -> int | None:
    """Return the integer position of the most recent trough on or before *idx*."""
    mask = trough_series.iloc[: idx + 1]
    positions = np.where(mask.values)[0]
    if len(positions) == 0:
        return None
    return int(positions[-1])

def compute_weekly_rsi(df_weekly: pd.DataFrame, period: int) -> pd.Series:
    """Wilder-smoothed RSI on weekly close prices."""
    close = df_weekly["close"]
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return rsi


# =========================================================================
# Signal evaluation (all 21 signals)
# =========================================================================

def eval_signals(
    df_d: pd.DataFrame,
    df_4h: pd.DataFrame,
    df_w: pd.DataFrame,
    d_idx: int,
    h_idx: int,
    w_idx: int,
    d_trough_pos: int | None,
    h_trough_pos: int | None,
    d_rsi21: pd.Series,
    d_rsi36: pd.Series,
    h_rsi21: pd.Series,
    h_rsi36: pd.Series,
    w_rsi21: pd.Series,
    w_rsi56: pd.Series,
    plus_di: pd.Series,
    minus_di: pd.Series,
    macd_line: pd.Series,
    crossover_price: float | None,
) -> dict:
    """Evaluate all 21 signals at a single daily bar.

    Returns
    -------
    dict  mapping signal_id → (pts: float, fired: bool)
    """
    results: dict[str, tuple[float, bool]] = {}

    close_d = df_d["close"].iloc[d_idx]

    # ------------------------------------------------------------------ Pool A
    # A1: Trough Detected (D) — 10 pts
    results["A1"] = (10.0, True) if d_trough_pos is not None else (0.0, False)

    # A2: Trough Detected (4H) — 8 pts
    results["A2"] = (8.0, True) if h_trough_pos is not None else (0.0, False)

    # A3: Recovery Momentum (D) — 8 pts
    a3_pts, a3_fired = 0.0, False
    if d_trough_pos is not None:
        bars = d_idx - d_trough_pos
        if 0 < bars <= 10:
            gain = d_rsi21.iloc[d_idx] - d_rsi21.iloc[d_trough_pos]
            if gain >= 8.0:
                a3_pts, a3_fired = 8.0, True
    results["A3"] = (a3_pts, a3_fired)

    # A4: Recovery Momentum (4H) — 6 pts
    a4_pts, a4_fired = 0.0, False
    if h_trough_pos is not None:
        bars = h_idx - h_trough_pos
        if 0 < bars <= 12:
            gain = h_rsi21.iloc[h_idx] - h_rsi21.iloc[h_trough_pos]
            if gain >= 10.0:
                a4_pts, a4_fired = 6.0, True
    results["A4"] = (a4_pts, a4_fired)

    # A5: RSI21 > 50 (4H) — 6 pts graded
    val = h_rsi21.iloc[h_idx]
    results["A5"] = (_graded(val, 6.0, 45.0, 55.0), not np.isnan(val) and val > 45.0)

    # A6: Multi-Speed Alignment (D) — 4 pts graded
    v21 = d_rsi21.iloc[d_idx]
    v36 = d_rsi36.iloc[d_idx]
    spread = v21 - v36
    results["A6"] = (
        _graded(spread, 4.0, -2.0, 2.0),
        spread > -2.0 if not np.isnan(spread) else False,
    )

    # ------------------------------------------------------------------ Pool B
    close_4h = df_4h["close"].iloc[h_idx]

    # B1: Close > TP28 (4H) — 7 pts graded
    tp_4h = df_4h["tp28"].iloc[h_idx]
    if not np.isnan(tp_4h):
        pct_b1 = (close_4h - tp_4h) / tp_4h * 100.0
        results["B1"] = (_graded(pct_b1, 7.0, -2.0, 1.0), pct_b1 > -2.0)
    else:
        results["B1"] = (0.0, False)

    # B2: Close > WC50 (4H) — 6 pts graded
    wc_4h = df_4h["wc50"].iloc[h_idx]
    if not np.isnan(wc_4h):
        pct_b2 = (close_4h - wc_4h) / wc_4h * 100.0
        results["B2"] = (_graded(pct_b2, 6.0, -2.0, 1.0), pct_b2 > -2.0)
    else:
        results["B2"] = (0.0, False)

    # B3: Approaching D-TP28 (D) — 5 pts (0.97× to 1.02× zone)
    tp_d = df_d["tp28"].iloc[d_idx]
    if not np.isnan(tp_d):
        if tp_d * 0.97 <= close_d <= tp_d * 1.02:
            results["B3"] = (5.0, True)
        else:
            results["B3"] = (0.0, False)
    else:
        results["B3"] = (0.0, False)

    # B4: Higher Low Forming (D) — 4 pts
    if d_trough_pos is not None:
        trough_low = df_d["low"].iloc[d_trough_pos]
        current_low = df_d["low"].iloc[d_idx]
        b4_fired = current_low > trough_low
        results["B4"] = (4.0 if b4_fired else 0.0, b4_fired)
    else:
        results["B4"] = (0.0, False)

    # B5: Price > Trough + 10% (D) — 3 pts
    if d_trough_pos is not None:
        trough_low = df_d["low"].iloc[d_trough_pos]
        b5_fired = close_d > trough_low * 1.10
        results["B5"] = (3.0 if b5_fired else 0.0, b5_fired)
    else:
        results["B5"] = (0.0, False)

    # B6: WC21 Proximity (4H) — 5 pts graded
    wc21_val = df_4h["wc21"].iloc[h_idx] if "wc21" in df_4h.columns else np.nan
    if not np.isnan(wc21_val) and close_4h > wc21_val and crossover_price is not None:
        pct_gain = (close_4h - crossover_price) / crossover_price * 100.0
        if 0 < pct_gain <= 5.0:
            pts_b6 = round(min(pct_gain, 5.0), 2)
            results["B6"] = (pts_b6, True)
        else:
            results["B6"] = (0.0, False)
    else:
        results["B6"] = (0.0, False)

    # ------------------------------------------------------------------ Pool C
    # C1: Cross-TF Trough Agree — 6 pts
    if d_trough_pos is not None and h_trough_pos is not None:
        d_trough_date = df_d.index[d_trough_pos]
        h_trough_date = df_4h.index[h_trough_pos]
        d_td = pd.Timestamp(d_trough_date).date()
        h_td = pd.Timestamp(h_trough_date).date()
        earlier = min(d_td, h_td)
        later = max(d_td, h_td)
        mask_c = (df_d.index.date > earlier) & (df_d.index.date < later)
        bars_between = int(mask_c.sum())
        c1_fired = bars_between <= 3
        results["C1"] = (6.0 if c1_fired else 0.0, c1_fired)
    else:
        results["C1"] = (0.0, False)

    # C2: 4H RSI36 > 45 — 4 pts graded
    val_c2 = h_rsi36.iloc[h_idx]
    results["C2"] = (_graded(val_c2, 4.0, 40.0, 50.0), not np.isnan(val_c2) and val_c2 > 40.0)

    # C3: W-RSI56 > 50 (prev W) — 4 pts
    if w_idx >= 1:
        prev_rsi56 = w_rsi56.iloc[w_idx - 1]
        c3_fired = not np.isnan(prev_rsi56) and prev_rsi56 > 50.0
        results["C3"] = (4.0 if c3_fired else 0.0, c3_fired)
    else:
        results["C3"] = (0.0, False)

    # C4: D-RSI21 > 45 — 4 pts graded
    val_c4 = d_rsi21.iloc[d_idx]
    results["C4"] = (_graded(val_c4, 4.0, 40.0, 50.0), not np.isnan(val_c4) and val_c4 > 40.0)

    # ---------------------------------------------------------------- Bonus A
    # BA1: Selling Exhaustion — disabled in v6 reproduction
    results["BA1"] = (0.0, False)

    # BA2: Price > Trough + 10% — 3 pts
    if d_trough_pos is not None:
        trough_low = df_d["low"].iloc[d_trough_pos]
        ba2_fired = close_d > trough_low * 1.10
        results["BA2"] = (3.0 if ba2_fired else 0.0, ba2_fired)
    else:
        results["BA2"] = (0.0, False)

    # BA3: 4H Volume Expansion — 2 pts
    ba3_pts, ba3_fired = 0.0, False
    if h_idx >= 20:
        avg_20 = df_4h["volume"].iloc[h_idx - 20 : h_idx].mean()
        if not np.isnan(avg_20) and avg_20 > 0:
            start = max(0, h_idx - 18)
            for v in df_4h["volume"].iloc[start : h_idx + 1]:
                if not np.isnan(v) and v > avg_20 * 1.5:
                    ba3_pts, ba3_fired = 2.0, True
                    break
    results["BA3"] = (ba3_pts, ba3_fired)

    # ---------------------------------------------------------------- Bonus B
    # BB1: 52W High > Current * 1.5 — 3 pts
    lookback = min(252, d_idx)
    if lookback >= 20:
        high_52w = df_d["high"].iloc[d_idx - lookback : d_idx + 1].max()
        bb1_fired = high_52w > close_d * 1.5
        results["BB1"] = (3.0 if bb1_fired else 0.0, bb1_fired)
    else:
        results["BB1"] = (0.0, False)

    # BB2: Multi-Touch Support — 4 pts
    bb2_pts, bb2_fired = 0.0, False
    lookback_bb2 = min(252, d_idx)
    if lookback_bb2 >= 30:
        window = df_d.iloc[d_idx - lookback_bb2 : d_idx + 1]
        lows = window["low"]
        rolling_min = lows.rolling(window=21, center=True, min_periods=21).min()
        trough_mask = lows == rolling_min
        trough_lows = lows[trough_mask].dropna()
        if len(trough_lows) >= 2:
            support_low = trough_lows.min()
            support_high = support_low + (trough_lows.max() - trough_lows.min()) * 0.3
            touches = lows[(lows >= support_low) & (lows <= support_high)]
            if len(touches) >= 2:
                bb2_pts, bb2_fired = 4.0, True
    results["BB2"] = (bb2_pts, bb2_fired)

    # BB3: Weekly RSI Reversal — 3 pts
    bb3_pts, bb3_fired = 0.0, False
    if w_idx >= 5:
        cur_rsi21 = w_rsi21.iloc[w_idx]
        cur_rsi56 = w_rsi56.iloc[w_idx]
        if not np.isnan(cur_rsi21) and not np.isnan(cur_rsi56):
            past_21 = w_rsi21.iloc[max(0, w_idx - 12) : w_idx]
            past_56 = w_rsi56.iloc[max(0, w_idx - 12) : w_idx]
            was_below = any(
                not np.isnan(p21) and not np.isnan(p56) and p21 < p56
                for p21, p56 in zip(past_21, past_56)
            )
            if was_below and cur_rsi21 > cur_rsi56:
                bb3_pts, bb3_fired = 3.0, True
    results["BB3"] = (bb3_pts, bb3_fired)

    # ---------------------------------------------------------------- Bonus C (binary)
    # BC1: ADX > -DI (Daily) — 2.5 pts
    pdi = plus_di.iloc[d_idx]
    mdi = minus_di.iloc[d_idx]
    bc1_fired = not np.isnan(pdi) and not np.isnan(mdi) and pdi > mdi
    results["BC1"] = (2.5 if bc1_fired else 0.0, bc1_fired)

    # BC2: MACD > 0 (Daily) — 2.5 pts
    macd_val = macd_line.iloc[d_idx]
    bc2_fired = not np.isnan(macd_val) and macd_val > 0
    results["BC2"] = (2.5 if bc2_fired else 0.0, bc2_fired)

    return results


# =========================================================================
# IPO Signal Evaluation (12 signals, trough-free)
# =========================================================================

IPO_MAX_RAW = sum(pts for _, _, _, pts in IPO_SIGNAL_DEFS)  # 69

def eval_ipo_signals(
    df_d: pd.DataFrame,
    df_4h: pd.DataFrame,
    d_idx: int,
    h_idx: int,
    listing_close: float | None = None,
) -> dict:
    """Evaluate all 12 IPO-specific signals at a single daily bar.

    These signals measure post-listing characteristics (momentum,
    structure, volume) that are observable without a trading history
    long enough for trough detection or 200-DMA computation.

    Parameters
    ----------
    df_d : pd.DataFrame  — daily OHLCV with indicator columns.
    df_4h : pd.DataFrame — 4H OHLCV with indicator columns.
    d_idx : int          — position in df_d.
    h_idx : int          — position in df_4h.

    Returns
    -------
    dict  mapping signal_id -> (pts: float, fired: bool)
    """
    results: dict[str, tuple[float, bool]] = {}

    close_d = df_d["close"].iloc[d_idx]
    low_d = df_d["low"].iloc[d_idx]
    # Use actual listing close from lookup if available, else first bar's close
    if listing_close is None:
        listing_close = df_d["close"].iloc[0]
    listing_low = df_d["low"].iloc[0]

    # Pre-computed series (assumed available from compute_all_indicators)
    d_rsi21 = df_d["rsi21"] if "rsi21" in df_d.columns else None
    h_rsi21 = df_4h["rsi21"] if "rsi21" in df_4h.columns else None

    # ---------------------------------------------------------------- Pool IM
    # I1: RSI Healthy Zone (D) — 8 pts graded
    # RSI(21) between 50-65: healthy momentum, not overbought
    if d_rsi21 is not None:
        val = float(d_rsi21.iloc[d_idx])
        if not np.isnan(val):
            if 50 <= val <= 65:
                i1_pts, i1_fired = 8.0, True
            elif 45 <= val < 50:
                i1_pts = _graded(val, 8.0, 45.0, 50.0)
                i1_fired = bool(val > 45)
            elif 65 < val <= 75:
                i1_pts = 8.0 - _graded(val, 8.0, 65.0, 75.0)
                i1_fired = True
            else:
                i1_pts, i1_fired = 0.0, False
            results["I1"] = (float(round(i1_pts, 2)), i1_fired)
        else:
            results["I1"] = (0.0, False)
    else:
        results["I1"] = (0.0, False)

    # I2: RSI Healthy Zone (4H) — 6 pts graded
    if h_rsi21 is not None:
        val = float(h_rsi21.iloc[h_idx])
        if not np.isnan(val):
            if 50 <= val <= 65:
                i2_pts, i2_fired = 6.0, True
            elif 45 <= val < 50:
                i2_pts = _graded(val, 6.0, 45.0, 50.0)
                i2_fired = bool(val > 45)
            elif 65 < val <= 75:
                i2_pts = 6.0 - _graded(val, 6.0, 65.0, 75.0)
                i2_fired = True
            else:
                i2_pts, i2_fired = 0.0, False
            results["I2"] = (float(round(i2_pts, 2)), i2_fired)
        else:
            results["I2"] = (0.0, False)
    else:
        results["I2"] = (0.0, False)

    # I3: Price Above Listing Close — 5 pts
    # Trading above the IPO closing price shows demand
    i3_fired = bool(close_d > listing_close)
    results["I3"] = (float(5.0 if i3_fired else 0.0), i3_fired)

    # I4: 4H RSI Stability — 8 pts
    # RSI(21) has held above 45 for at least 10 of the last 15 four-hour bars
    i4_pts, i4_fired = 0.0, False
    if h_rsi21 is not None and h_idx >= 15:
        window_rsi = h_rsi21.iloc[h_idx - 14: h_idx + 1]
        above_45 = window_rsi.dropna() > 45
        hold_ratio = float(above_45.sum()) / max(1, len(above_45))
        if hold_ratio >= 0.80:
            i4_pts, i4_fired = 8.0, True
        elif hold_ratio >= 0.60:
            i4_pts = _graded(hold_ratio, 8.0, 0.60, 0.80)
            i4_fired = hold_ratio >= 0.60
    results["I4"] = (round(i4_pts, 2), i4_fired)

    # ---------------------------------------------------------------- Pool IS
    # I5: Higher Highs Since Listing — 7 pts
    # At least 2 distinct higher highs in the last 20 daily bars
    i5_pts, i5_fired = 0.0, False
    lookback_i5 = min(20, d_idx)
    if lookback_i5 >= 5:
        recent_highs = df_d["high"].iloc[d_idx - lookback_i5: d_idx + 1]
        # Find local peaks (higher than neighbours)
        peaks = []
        for j in range(1, len(recent_highs) - 1):
            if (recent_highs.iloc[j] > recent_highs.iloc[j - 1]
                    and recent_highs.iloc[j] > recent_highs.iloc[j + 1]):
                peaks.append(float(recent_highs.iloc[j]))
        if len(peaks) >= 2:
            is_higher = all(peaks[k] > peaks[k - 1] for k in range(1, len(peaks)))
            if is_higher:
                i5_pts, i5_fired = 7.0, True
            elif len(peaks) >= 2:
                i5_pts, i5_fired = 3.5, True  # partial credit
    results["I5"] = (round(i5_pts, 2), i5_fired)

    # I6: Higher Lows Since Listing — 5 pts
    i6_pts, i6_fired = 0.0, False
    lookback_i6 = min(20, d_idx)
    if lookback_i6 >= 5:
        recent_lows = df_d["low"].iloc[d_idx - lookback_i6: d_idx + 1]
        troughs = []
        for j in range(1, len(recent_lows) - 1):
            if (recent_lows.iloc[j] < recent_lows.iloc[j - 1]
                    and recent_lows.iloc[j] < recent_lows.iloc[j + 1]):
                troughs.append(float(recent_lows.iloc[j]))
        if len(troughs) >= 2:
            is_higher = all(troughs[k] > troughs[k - 1] for k in range(1, len(troughs)))
            if is_higher:
                i6_pts, i6_fired = 5.0, True
            elif len(troughs) >= 2:
                i6_pts, i6_fired = 2.5, True  # partial credit
    results["I6"] = (round(i6_pts, 2), i6_fired)

    # I7: Listing Low Intact — 4 pts
    # The listing day low has not been breached
    all_lows = df_d["low"].iloc[: d_idx + 1]
    i7_fired = bool(low_d >= listing_low and all_lows.min() >= listing_low * 0.99)
    results["I7"] = (4.0 if i7_fired else 0.0, i7_fired)

    # I8: Narrowing Volatility — 5 pts
    # ATR(14) declining over last 10 bars: post-listing chaos is settling
    i8_pts, i8_fired = 0.0, False
    if "atr" in df_d.columns and d_idx >= 15:
        atr_series = df_d["atr"].iloc[d_idx - 14: d_idx + 1].dropna()
        if len(atr_series) >= 10:
            first_half = atr_series.iloc[: len(atr_series) // 2].mean()
            second_half = atr_series.iloc[len(atr_series) // 2 :].mean()
            if first_half > 0 and second_half < first_half:
                shrink_pct = (first_half - second_half) / first_half
                if shrink_pct >= 0.15:
                    i8_pts, i8_fired = 5.0, True
                elif shrink_pct >= 0.05:
                    i8_pts = _graded(shrink_pct, 5.0, 0.05, 0.15)
                    i8_fired = True
    results["I8"] = (round(i8_pts, 2), i8_fired)

    # ---------------------------------------------------------------- Pool IV
    # I9: Volume Trend Positive — 5 pts
    # 10-day average volume > 20-day average volume
    i9_pts, i9_fired = 0.0, False
    if d_idx >= 25 and "volume" in df_d.columns:
        vol_short = df_d["volume"].iloc[d_idx - 9: d_idx + 1].mean()
        vol_long = df_d["volume"].iloc[d_idx - 24: d_idx + 1].mean()
        if not np.isnan(vol_short) and not np.isnan(vol_long) and vol_long > 0:
            vol_ratio = vol_short / vol_long
            if vol_ratio > 1.1:
                i9_pts, i9_fired = 5.0, True
            elif vol_ratio > 0.9:
                i9_pts = _graded(vol_ratio, 5.0, 0.9, 1.1)
                i9_fired = bool(vol_ratio > 0.9)
    results["I9"] = (round(i9_pts, 2), i9_fired)

    # I10: 20-DMA Slope Up — 6 pts
    # 20-day moving average has positive slope over last 5 bars
    i10_pts, i10_fired = 0.0, False
    if d_idx >= 25:
        dma20 = df_d["close"].rolling(window=20, min_periods=20).mean()
        if d_idx >= 25 and not np.isnan(dma20.iloc[d_idx]):
            slope = (dma20.iloc[d_idx] - dma20.iloc[d_idx - 5]) / 5.0
            price_ref = dma20.iloc[d_idx - 5]
            if not np.isnan(price_ref) and price_ref > 0:
                slope_pct = slope / price_ref * 100.0
                if slope_pct > 0.1:
                    i10_pts, i10_fired = 6.0, True
                elif slope_pct > 0:
                    i10_pts = _graded(slope_pct, 6.0, 0.0, 0.1)
                    i10_fired = bool(slope_pct > 0)
    results["I10"] = (round(i10_pts, 2), i10_fired)

    # I11: Price Above 20-DMA — 5 pts
    i11_pts, i11_fired = 0.0, False
    if d_idx >= 20:
        dma20 = df_d["close"].rolling(window=20, min_periods=20).mean()
        dma_val = dma20.iloc[d_idx]
        if not np.isnan(dma_val) and dma_val > 0:
            pct_above = float((close_d - dma_val) / dma_val * 100.0)
            if pct_above > 0:
                i11_fired = True
                if pct_above <= 5.0:
                    # Ideal: close to DMA, not stretched
                    i11_pts = _graded(pct_above, 5.0, 0.0, 5.0)
                elif pct_above <= 10.0:
                    i11_pts = _graded(10.0 - pct_above, 5.0, 0.0, 5.0)
                else:
                    i11_pts = 0.0  # too far above
    results["I11"] = (round(i11_pts, 2), i11_fired)

    # I12: Multi-TF Trend Alignment — 5 pts
    # Both daily and 4H RSI(21) above 50 and daily close > 20-DMA
    i12_pts, i12_fired = 0.0, False
    d_rsi_ok = bool(
        d_rsi21 is not None
        and not np.isnan(d_rsi21.iloc[d_idx])
        and d_rsi21.iloc[d_idx] > 50
    )
    h_rsi_ok = bool(
        h_rsi21 is not None
        and not np.isnan(h_rsi21.iloc[h_idx])
        and h_rsi21.iloc[h_idx] > 50
    )
    if d_idx >= 20:
        dma20 = df_d["close"].rolling(window=20, min_periods=20).mean()
        price_above_dma = (not np.isnan(dma20.iloc[d_idx])
                           and close_d > dma20.iloc[d_idx])
    else:
        price_above_dma = False
    if d_rsi_ok and h_rsi_ok and price_above_dma:
        i12_pts, i12_fired = 5.0, True
    elif d_rsi_ok and (h_rsi_ok or price_above_dma):
        i12_pts, i12_fired = 2.5, True  # partial
    results["I12"] = (round(i12_pts, 2), i12_fired)

    return results

def _normalize_ipo_score(raw_score: float) -> float:
    """Map IPO raw score (0-69) to normalized 0-100 scale.

    Uses linear mapping: normalized = (raw / IPO_MAX_RAW) * 100.
    Scores below 0 are clamped to 0; scores above 100 are clamped to 100.
    This ensures IPO scores are directly comparable to mature stock
    scores in the same ranking table.
    """
    if IPO_MAX_RAW <= 0:
        return 0.0
    clamped = max(0.0, min(float(raw_score), float(IPO_MAX_RAW)))
    return round(float(clamped / IPO_MAX_RAW * 100.0), 2)
