"""Apollo Live Engine — Streamlit Dashboard.

Phase 2 Step 3 (v1.3) — Multi-stock watchlist mode + paced replay.

v1.3 features:
- **Multi-stock mode** — monitor all watchlist stocks (my_watchlist.json)
  whose CSV is in data/, in parallel. Round-robin replay with configurable
  pace (1s/2s/5s/10s/30s per bar).
- **Grid view** — small chart per stock in a responsive grid. Click a stock
  to expand its full chart + alerts in the main area.
- **Chart zoom** — native Plotly scroll-wheel zoom + drag pan + range slider
  below every chart.
- **Combined alerts feed** — when in multi-stock mode, shows latest alerts
  across ALL stocks in one table.
- Backward compatible with v1.2 single-stock mode (toggle in sidebar).

v1.2 bugfix: dynamic symbol dropdown (only shows CSVs that exist).
v1.1: human-in-the-loop exit confirmation (Confirm/Dismiss buttons).

This dashboard reads from the same SQLite state store the
``SignalMonitor`` writes to. The monitor runs as a separate subprocess
(started from this UI or from the CLI), and the dashboard polls the
state store for live updates.

Key features
------------
* **Symbol + date range selector** — pick which stock and period to
  monitor. The 5 test stocks (APOLLO, CYIENTDLM, SYRMA, JYOTICNC,
  KAYNES) are pre-loaded.

* **KPI row** — at-a-glance position state, current score, last entry,
  last alert, total alert count.

* **Score history chart** — full daily score over the selected date
  range (computed via ``BarReplay``), with markers for ENTRY alerts
  (green up-arrows) and EXIT alerts (red down-arrows). Horizontal
  lines mark the entry/exit thresholds.

* **Pending exit panel** — when the monitor is running in
  human-confirm mode (``--no-auto-confirm``) and an EXIT alert fires,
  the position is marked ``pending_exit``. This panel shows the exit
  reason, fill price, P&L, and provides:
    - **"✓ Confirm Exit"** button — resets position, sets cooldown.
    - **"✗ Dismiss"** button — keeps position open, clears pending state.

* **Recent alerts table** — last 20 alerts (any type) with timestamp,
  type, score, and message.

* **Monitor controls** — start the monitor as a background subprocess
  (auto-confirm or human-confirm mode), stop it, reset all state for
  the selected symbol.

Run
---
    streamlit run live_engine/dashboard.py

Or use the launcher::

    python live_engine/run_live.py
"""

from __future__ import annotations

import os
import sys
import subprocess
import signal
import json
import tempfile
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

import pandas as pd
import numpy as np

# Ensure project root is on sys.path so apollo_core + live_engine import cleanly
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import streamlit as st

# Lazy/optional plotly import — we fall back to st.line_chart if unavailable
try:
    import plotly.graph_objects as go
    _PLOTLY_AVAILABLE = True
except ImportError:
    _PLOTLY_AVAILABLE = False

from apollo_core.types import Position
from apollo_core.constants import ENTRY_THRESHOLD, EXIT_THRESHOLD, DIVERGENCE_COOLDOWN
from live_engine import __version__ as LIVE_VERSION
from live_engine.data_replay import BarReplay
from live_engine.state_store import StateStore
from live_engine.signal_monitor import (
    confirm_exit, dismiss_exit,
    ALERT_ENTRY, ALERT_EXIT, ALERT_HOLD, ALERT_WAIT,
    ALERT_COOLDOWN, ALERT_STARTUP,
    ALERT_EXIT_CONFIRMED, ALERT_EXIT_DISMISSED,
)


# =========================================================================
# Constants
# =========================================================================

TEST_STOCKS = ["APOLLO", "CYIENTDLM", "SYRMA", "JYOTICNC", "KAYNES"]
DEFAULT_DATA_DIR = str(Path(_PROJECT_ROOT) / "data")
DEFAULT_DB_PATH = str(Path(_PROJECT_ROOT) / "live_state.db")
DEFAULT_START = "2024-01-01"
DEFAULT_END = datetime.utcnow().strftime("%Y-%m-%d")

# Default symbol to highlight in the dropdown. CYIENTDLM is the regression
# baseline stock and is always shipped in the zip's data/ folder, so it's
# the safest default. If CYIENTDLM.csv is missing we fall back to whatever
# is first in the available-symbols list at render time.
DEFAULT_SYMBOL = "CYIENTDLM"

# Color palette (teal accent like the backtest dashboard, plus alert colors)
COLOR_PRIMARY = "#14b8a6"     # teal-500
COLOR_ENTRY = "#10b981"       # emerald-500 (green)
COLOR_EXIT = "#ef4444"        # red-500
COLOR_PENDING = "#f59e0b"     # amber-500
COLOR_MUTED = "#64748b"       # slate-500
COLOR_BG = "#0f172a"          # slate-900 (for dark cards)


# =========================================================================
# Cached data loading
# =========================================================================

def list_available_symbols(data_dir: str) -> list[str]:
    """Scan ``data_dir`` for ``{SYMBOL}.csv`` files and return sorted symbol list.

    Looks for files matching ``<NAME>.csv`` (case-insensitive) where ``<NAME>``
    is a valid NSE stock symbol. Returns symbols sorted with the 5 known
    test stocks first (in their declared order), then any extras alphabetically.

    This is what populates the symbol dropdown in the sidebar — only stocks
    whose CSV is actually on disk are selectable. Prevents the v1.1 bug
    where the dropdown offered 5 stocks but the zip only shipped 1 CSV.
    """
    p = Path(data_dir)
    if not p.is_dir():
        return []
    found = set()
    for f in p.glob("*.csv"):
        # Skip the *_D.csv and *_4H.csv sidecars — those are intermediate
        # files produced by load_eod2_stock, not primary symbol feeds.
        name = f.stem
        if name.endswith("_D") or name.endswith("_4H") or name.endswith("_W"):
            continue
        found.add(name.upper())
    # Order: known test stocks first (in declared order), then extras alpha
    ordered = [s for s in TEST_STOCKS if s in found]
    extras = sorted(s for s in found if s not in TEST_STOCKS)
    return ordered + extras


@st.cache_data(ttl=60, show_spinner=False)
def list_available_symbols_cached(data_dir: str) -> list[str]:
    """Cached wrapper around list_available_symbols (60-second TTL).

    Cached so switching other sidebar controls doesn't rescan the disk.
    Use the un-cached ``list_available_symbols`` if you need a fresh scan.
    """
    return list_available_symbols(data_dir)


@st.cache_data(ttl=300, show_spinner=False)
def load_score_history(data_dir: str, symbol: str,
                        start_date: str, end_date: str) -> pd.DataFrame:
    """Load full daily score history for the chart.

    Uses ``BarReplay`` to run the scoring engine once on the full date
    range, then returns a DataFrame with columns: date, close, score,
    rsi, action. Cached for 5 minutes to avoid recomputation.
    """
    # Pre-check: explicit, friendly error if the CSV is missing.
    csv_path = Path(data_dir) / f"{symbol}.csv"
    if not csv_path.exists():
        st.error(
            f"No CSV file found for **{symbol}**.\n\n"
            f"Expected file: `{csv_path}`\n\n"
            f"Place `{symbol}.csv` in your data directory and click "
            f"'Refresh symbol list' in the sidebar. The dropdown only "
            f"shows stocks whose CSV is present in `{data_dir}`."
        )
        return pd.DataFrame(columns=["date", "close", "score", "rsi", "action"])
    try:
        replay = BarReplay(
            data_dir=data_dir, symbol=symbol,
            start_date=start_date, end_date=end_date,
        )
        rows = []
        for bar in replay.replay():
            r = bar.daily_result
            rows.append({
                "date": r["date"],
                "close": r["close"],
                "score": r["total"],
                "rsi": r["rsi21"],
                "action": r["action"],
                "bars_from_trough": r["bars_from_trough"],
            })
        df = pd.DataFrame(rows)
        if not df.empty:
            df["date"] = pd.to_datetime(df["date"])
        return df
    except FileNotFoundError as e:
        st.error(
            f"Missing data file for **{symbol}**: {e}\n\n"
            f"Make sure `{symbol}.csv` is in `{data_dir}`."
        )
        return pd.DataFrame(columns=["date", "close", "score", "rsi", "action"])
    except Exception as e:
        st.error(f"Failed to load score history: {type(e).__name__}: {e}")
        return pd.DataFrame(columns=["date", "close", "score", "rsi", "action"])


@st.cache_data(ttl=300, show_spinner=False)
def load_df_d(data_dir: str, symbol: str) -> Optional[pd.DataFrame]:
    """Load the daily DataFrame (with indicators) for cooldown lookup."""
    try:
        from backtest_engine.eod2_loader import load_eod2_stock
        df_d, _, _ = load_eod2_stock(data_dir, symbol)
        return df_d
    except Exception:
        return None


# =========================================================================
# Monitor subprocess management
# =========================================================================

def _start_monitor_subprocess(
    symbol: str, data_dir: str, start_date: str, end_date: str,
    db_path: str, exit_mode: str, sl_percent: float, trailing_sl: float,
    entry_thresh: float, exit_thresh: float, auto_confirm: bool,
    multi_stock: bool = False, watchlist_path: Optional[str] = None,
    pace_seconds: float = 2.0,
) -> Optional[int]:
    """Start the live monitor as a detached subprocess. Returns PID.

    If ``multi_stock=True`` (v1.3), starts in multi-stock mode using
    ``--watchlist`` + ``--pace-seconds`` flags. ``symbol`` is ignored in
    this case (the monitor scans the watchlist + data dir itself).
    """
    cmd = [
        sys.executable, "-m", "live_engine",
        "--data-dir", data_dir,
        "--start", start_date,
        "--end", end_date,
        "--db", db_path,
        "--exit-mode", exit_mode,
        "--sl-percent", str(sl_percent),
        "--trailing-sl", str(trailing_sl),
        "--entry-thresh", str(entry_thresh),
        "--exit-thresh", str(exit_thresh),
        "--quiet",
    ]
    if multi_stock and watchlist_path:
        cmd.extend(["--watchlist", watchlist_path,
                    "--pace-seconds", str(pace_seconds)])
    else:
        cmd.extend(["--symbol", symbol])
    if not auto_confirm:
        cmd.append("--no-auto-confirm")
    if not auto_confirm:
        # In human-confirm mode, we want to see HOLD/EXIT alerts too
        cmd = [c for c in cmd if c != "--quiet"]

    try:
        # Detach so the monitor survives the dashboard process
        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            **kwargs,
        )
        return proc.pid
    except Exception as e:
        st.error(f"Failed to start monitor: {type(e).__name__}: {e}")
        return None


def _stop_monitor_subprocess(pid: int) -> bool:
    """Terminate a monitor subprocess by PID."""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                            capture_output=True)
        else:
            os.kill(pid, signal.SIGTERM)
        return True
    except Exception:
        return False


def _is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running."""
    if pid is None:
        return False
    try:
        if os.name == "nt":
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}"],
                capture_output=True, text=True,
            )
            return str(pid) in result.stdout
        else:
            os.kill(pid, 0)  # signal 0 = check existence
            return True
    except (OSError, ProcessLookupError):
        return False


# =========================================================================
# StateStore helpers
# =========================================================================

def _load_position(db_path: str, symbol: str) -> tuple[Optional[Position], Optional[pd.Timestamp]]:
    """Load Position + last_processed_date from SQLite. Returns (None, None) on error."""
    try:
        with StateStore(db_path) as store:
            return store.load_position(symbol)
    except Exception:
        return None, None


def _load_alerts(db_path: str, symbol: str, limit: int = 50) -> list[dict]:
    """Load most recent alerts for the symbol."""
    try:
        with StateStore(db_path) as store:
            # list_alerts returns oldest-first; we want most recent first
            alerts = store.list_alerts(symbol=symbol)
            return alerts[-limit:][::-1] if alerts else []
    except Exception:
        return []


def _count_alerts(db_path: str, symbol: str) -> int:
    try:
        with StateStore(db_path) as store:
            return store.count_alerts(symbol=symbol)
    except Exception:
        return 0


# =========================================================================
# UI components
# =========================================================================

def _render_header():
    """Top-of-page header."""
    st.markdown(
        f"""
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">
            <span style="font-size:32px;">🛰️</span>
            <h1 style="margin:0; color:{COLOR_PRIMARY}; font-family:monospace;">
                Apollo Live Monitor
            </h1>
            <span style="background:{COLOR_PRIMARY}; color:white; padding:2px 10px;
                         border-radius:12px; font-size:13px; font-weight:600;">
                v{LIVE_VERSION}
            </span>
        </div>
        <p style="color:{COLOR_MUTED}; margin-top:0;">
            Live signal monitor &mdash; advisory alerts only. Uses the same
            <code>detect_exit_triggers()</code> as the backtest engine.
        </p>
        """,
        unsafe_allow_html=True,
    )


def _render_sidebar() -> dict:
    """Render sidebar controls. Returns a dict of all control values."""
    st.sidebar.markdown("### ⚙️ Monitor Configuration")

    # ===== Mode toggle (v1.3): single-stock vs. multi-stock watchlist =====
    mode_options = ["Single-stock", "Multi-stock (watchlist)"]
    mode_idx = st.sidebar.radio(
        "Monitor mode",
        options=range(len(mode_options)),
        format_func=lambda i: mode_options[i],
        index=0,
        key="monitor_mode_radio",
        help="Single-stock: monitor one stock at a time (v1.2 behavior). "
             "Multi-stock: monitor all watchlist stocks whose CSV is in data/ "
             "(v1.3 — true live-scanner feel with paced replay).",
    )
    multi_stock_mode = (mode_idx == 1)

    # Data dir is captured first so we can scan it for available symbols.
    data_dir = st.sidebar.text_input("Data directory", value=DEFAULT_DATA_DIR, key="data_dir_input")

    cfg_extra = {"multi_stock_mode": multi_stock_mode, "data_dir": data_dir}

    if multi_stock_mode:
        return _render_sidebar_multi(cfg_extra)
    # else: single-stock mode (v1.2 behavior)
    return _render_sidebar_single_legacy(cfg_extra)


def _render_sidebar_multi(cfg_extra: dict) -> dict:
    """Render sidebar in multi-stock mode (v1.3). Returns full cfg dict."""
    from live_engine.watchlist import DEFAULT_WATCHLIST_PATH, load_available

    data_dir = cfg_extra["data_dir"]
    watchlist_path = st.sidebar.text_input(
        "Watchlist JSON file",
        value=DEFAULT_WATCHLIST_PATH,
        key="watchlist_path_input",
        help="JSON file with stock list. Default: my_watchlist.json at project root.",
    )

    # Scan watchlist + data dir for available stocks
    available = load_available(watchlist_path=watchlist_path, data_dir=data_dir)
    available_symbols = [e["sym"] for e in available]

    if not available_symbols:
        st.sidebar.warning(
            f"No watchlist stocks have CSVs in `{data_dir}`. "
            f"Drop at least one `SYMBOL.csv` (e.g., `CYIENTDLM.csv`) "
            f"in the data dir and click Refresh."
        )
    else:
        st.sidebar.success(
            f"**{len(available_symbols)} stock(s) available** for monitoring: "
            f"{', '.join(available_symbols[:5])}"
            f"{'...' if len(available_symbols) > 5 else ''}"
        )

    # Pace slider (v1.3) — controls how fast bars stream in
    pace_seconds = st.sidebar.slider(
        "Replay pace (seconds per bar)",
        min_value=0.0, max_value=30.0, value=2.0, step=0.5,
        key="pace_seconds_slider",
        help="0 = instant (finishes in seconds). 2 = year of data streams "
             "over ~8 min per stock. Higher = more 'live' feel."
    )

    if st.sidebar.button("↻ Refresh watchlist", use_container_width=False):
        st.rerun()

    col1, col2 = st.sidebar.columns(2)
    with col1:
        start_date = st.sidebar.text_input("Start date", value=DEFAULT_START, key="start_date_input")
    with col2:
        end_date = st.sidebar.text_input("End date", value=DEFAULT_END, key="end_date_input")

    st.sidebar.markdown("---")
    st.sidebar.markdown("#### Exit Configuration (applies to ALL stocks)")
    exit_mode = st.sidebar.selectbox(
        "Exit mode",
        ["NONE", "FIXED_SL", "TRAILING_SL", "DUAL_SL", "DI_CROSSOVER"],
        index=0, key="exit_mode_select",
        help="NONE = score-threshold + divergence only. SL modes add stop-loss logic.",
    )
    sl_pct = st.sidebar.number_input("Hard SL %", min_value=0.0, max_value=50.0,
                                       value=5.0, step=0.5, key="sl_pct_input")
    trail_pct = st.sidebar.number_input("Trailing SL %", min_value=0.0, max_value=50.0,
                                          value=3.0, step=0.5, key="trail_pct_input")
    entry_thresh = st.sidebar.number_input("Entry threshold", min_value=0.0, max_value=100.0,
                                             value=float(ENTRY_THRESHOLD), step=1.0, key="entry_thresh_input")
    exit_thresh = st.sidebar.number_input("Exit threshold", min_value=0.0, max_value=100.0,
                                            value=float(EXIT_THRESHOLD), step=1.0, key="exit_thresh_input")

    st.sidebar.markdown("---")
    st.sidebar.markdown("#### State DB")
    db_path = st.sidebar.text_input("SQLite DB path", value=DEFAULT_DB_PATH, key="db_path_input")

    st.sidebar.markdown("---")
    st.sidebar.markdown("#### Monitor Process")
    auto_confirm = st.sidebar.checkbox(
        "Auto-confirm exits (Step 2 mode)",
        value=False,
        key="auto_confirm_checkbox",
        help="If checked, EXIT alerts auto-close the position. If unchecked (default), "
             "EXIT alerts become PENDING and require you to click 'Confirm Exit' "
             "in the dashboard for that stock.",
    )

    # In multi mode, the "selected symbol" is whatever the user clicks
    # in the grid (defaults to first available). Used for the detail view.
    selected_symbol = st.session_state.get("selected_symbol")
    if selected_symbol is None and available_symbols:
        selected_symbol = available_symbols[0]
        st.session_state.selected_symbol = selected_symbol

    return {
        **cfg_extra,
        "symbol": selected_symbol or "",
        "watchlist_path": watchlist_path,
        "available_symbols": available_symbols,
        "pace_seconds": pace_seconds,
        "start_date": start_date,
        "end_date": end_date,
        "exit_mode": exit_mode,
        "sl_pct": sl_pct,
        "trail_pct": trail_pct,
        "entry_thresh": entry_thresh,
        "exit_thresh": exit_thresh,
        "db_path": db_path,
        "auto_confirm": auto_confirm,
    }


def _render_sidebar_single_legacy(cfg_extra: dict) -> dict:
    """Render sidebar in single-stock mode (v1.2 behavior). Returns full cfg dict.

    This is the original v1.2 sidebar logic, factored out so the new v1.3
    multi-stock toggle can dispatch to either path cleanly.
    """
    data_dir = cfg_extra["data_dir"]

    # Scan data_dir for available *.csv files (excluding *_D, *_4H, *_W sidecars).
    available_symbols = list_available_symbols_cached(data_dir)

    # If the data_dir is empty / missing, fall back to the hardcoded list
    # so the dropdown isn't empty — the user will see a friendly error
    # when they pick a stock with no CSV instead of a broken UI.
    if not available_symbols:
        available_symbols = list(TEST_STOCKS)
        st.sidebar.warning(
            f"No CSV files found in `{data_dir}`. Place at least one "
            f"`SYMBOL.csv` file there and click '↻ Refresh symbol list'."
        )

    # Pick default selection: prefer DEFAULT_SYMBOL (CYIENTDLM) if available,
    # else fall back to the first available symbol.
    default_symbol = DEFAULT_SYMBOL if DEFAULT_SYMBOL in available_symbols else available_symbols[0]
    default_index = available_symbols.index(default_symbol)

    # Preserve user's prior selection across reruns if it's still in the list.
    prior = st.session_state.get("symbol_select")
    if prior in available_symbols:
        default_index = available_symbols.index(prior)

    symbol = st.sidebar.selectbox(
        "Symbol",
        available_symbols,
        index=default_index,
        key="symbol_select",
        help=f"Only stocks whose CSV is in `{data_dir}` are listed. "
             f"Found {len(available_symbols)} CSV(s).",
    )

    # Refresh button so the user can re-scan after dropping a new CSV in.
    if st.sidebar.button("↻ Refresh symbol list", use_container_width=False):
        list_available_symbols_cached.clear()
        st.rerun()

    col1, col2 = st.sidebar.columns(2)
    with col1:
        start_date = st.sidebar.text_input("Start date", value=DEFAULT_START, key="start_date_input")
    with col2:
        end_date = st.sidebar.text_input("End date", value=DEFAULT_END, key="end_date_input")

    st.sidebar.markdown("---")
    st.sidebar.markdown("#### Exit Configuration")
    exit_mode = st.sidebar.selectbox(
        "Exit mode",
        ["NONE", "FIXED_SL", "TRAILING_SL", "DUAL_SL", "DI_CROSSOVER"],
        index=0, key="exit_mode_select",
        help="NONE = score-threshold + divergence only. SL modes add stop-loss logic.",
    )
    sl_pct = st.sidebar.number_input("Hard SL %", min_value=0.0, max_value=50.0,
                                       value=5.0, step=0.5, key="sl_pct_input")
    trail_pct = st.sidebar.number_input("Trailing SL %", min_value=0.0, max_value=50.0,
                                          value=3.0, step=0.5, key="trail_pct_input")
    entry_thresh = st.sidebar.number_input("Entry threshold", min_value=0.0, max_value=100.0,
                                             value=float(ENTRY_THRESHOLD), step=1.0, key="entry_thresh_input")
    exit_thresh = st.sidebar.number_input("Exit threshold", min_value=0.0, max_value=100.0,
                                            value=float(EXIT_THRESHOLD), step=1.0, key="exit_thresh_input")

    st.sidebar.markdown("---")
    st.sidebar.markdown("#### State DB")
    db_path = st.sidebar.text_input("SQLite DB path", value=DEFAULT_DB_PATH, key="db_path_input")

    st.sidebar.markdown("---")
    st.sidebar.markdown("#### Monitor Process")
    auto_confirm = st.sidebar.checkbox(
        "Auto-confirm exits (Step 2 mode)",
        value=False,
        key="auto_confirm_checkbox",
        help="If checked, EXIT alerts auto-close the position (Step 2 behavior — for verifying the engine). "
             "If unchecked (default in v1.1), EXIT alerts become PENDING and require you to click "
             "'Confirm Exit' in the dashboard. This is the human-in-the-loop live-trading mode.",
    )

    return {
        **cfg_extra,
        "symbol": symbol,
        "watchlist_path": None,
        "available_symbols": available_symbols,
        "pace_seconds": 0.0,
        "start_date": start_date,
        "end_date": end_date,
        "exit_mode": exit_mode,
        "sl_pct": sl_pct,
        "trail_pct": trail_pct,
        "entry_thresh": entry_thresh,
        "exit_thresh": exit_thresh,
        "db_path": db_path,
        "auto_confirm": auto_confirm,
    }


def _render_monitor_controls(cfg: dict):
    """Render the start/stop/reset buttons. Returns the current monitor PID."""
    pid: Optional[int] = st.session_state.get("monitor_pid")

    col_start, col_stop, col_reset, col_status = st.columns([1.2, 1, 1, 1.8])

    with col_start:
        if st.button("▶ Start Monitor", type="primary", use_container_width=True):
            pid = _start_monitor_subprocess(
                cfg["symbol"], cfg["data_dir"], cfg["start_date"], cfg["end_date"],
                cfg["db_path"], cfg["exit_mode"], cfg["sl_pct"], cfg["trail_pct"],
                cfg["entry_thresh"], cfg["exit_thresh"], cfg["auto_confirm"],
                multi_stock=cfg.get("multi_stock_mode", False),
                watchlist_path=cfg.get("watchlist_path"),
                pace_seconds=cfg.get("pace_seconds", 0.0),
            )
            if pid is not None:
                st.session_state.monitor_pid = pid
                st.session_state.monitor_started_at = datetime.utcnow()
                if cfg.get("multi_stock_mode"):
                    st.success(f"Multi-stock monitor started (PID {pid}). "
                               f"Replay pace: {cfg.get('pace_seconds', 0.0)}s/bar. "
                               f"Watch: alerts stream in below.")
                else:
                    st.success(f"Monitor started (PID {pid}). Processing bars...")
            st.rerun()

    with col_stop:
        if st.button("⏹ Stop Monitor", use_container_width=True,
                      disabled=(pid is None)):
            if pid is not None and _stop_monitor_subprocess(pid):
                st.session_state.monitor_pid = None
                st.success(f"Monitor (PID {pid}) stopped.")
            else:
                st.error(f"Failed to stop monitor (PID {pid}).")
            st.rerun()

    with col_reset:
        if st.button("🗑 Reset State", use_container_width=True):
            try:
                with StateStore(cfg["db_path"]) as store:
                    store.clear_position(cfg["symbol"])
                st.success(f"State cleared for {cfg['symbol']}.")
                st.rerun()
            except Exception as e:
                st.error(f"Reset failed: {e}")

    with col_status:
        if pid is not None:
            alive = _is_process_alive(pid)
            if alive:
                st.markdown(
                    f"<span style='color:{COLOR_ENTRY};'>●</span> "
                    f"<b>Monitor running</b> (PID {pid})",
                    unsafe_allow_html=True,
                )
            else:
                st.markdown(
                    f"<span style='color:{COLOR_MUTED};'>●</span> "
                    f"<b>Monitor exited</b> (PID {pid})",
                    unsafe_allow_html=True,
                )
                # Clear stale PID
                if "monitor_pid" in st.session_state:
                    del st.session_state.monitor_pid
        else:
            st.markdown(
                f"<span style='color:{COLOR_MUTED};'>●</span> "
                f"<b>Monitor not running</b>",
                unsafe_allow_html=True,
            )


def _render_kpi_row(cfg: dict, position: Optional[Position], alerts: list[dict]):
    """Top-row KPI cards."""
    if position is None:
        pos_status = "NO DATA"
        pos_color = COLOR_MUTED
        entry_str = "—"
    elif position.pending_exit:
        pos_status = "PENDING EXIT"
        pos_color = COLOR_PENDING
        entry_str = f"₹{position.entry_price:.2f}" if position.entry_price else "—"
    elif position.in_trade:
        pos_status = "IN TRADE"
        pos_color = COLOR_ENTRY
        entry_str = f"₹{position.entry_price:.2f}" if position.entry_price else "—"
    elif position.cooldown_until_date is not None:
        pos_status = "COOLDOWN"
        pos_color = COLOR_PENDING
        entry_str = "—"
    else:
        pos_status = "FLAT"
        pos_color = COLOR_MUTED
        entry_str = "—"

    # Latest score (from alerts, fallback to score history)
    latest_score = "—"
    if alerts:
        # Find the most recent alert with a score in its payload
        for a in alerts:
            payload = _parse_payload(a)
            if payload and "score" in payload:
                latest_score = f"{payload['score']:.1f}"
                break

    # Last alert
    if alerts:
        last = alerts[0]
        last_alert_str = f"{last['alert_type']}"
    else:
        last_alert_str = "—"

    total_alerts = len(alerts) if alerts else 0

    # Use st.metric for clean KPI cards
    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        st.metric("Position", pos_status)
        st.markdown(
            f"<div style='height:4px; background:{pos_color}; border-radius:2px; "
            f"margin-top:-8px;'></div>",
            unsafe_allow_html=True,
        )
    with col2:
        st.metric("Latest Score", latest_score)
    with col3:
        st.metric("Entry Price", entry_str)
    with col4:
        st.metric("Last Alert", last_alert_str)
    with col5:
        st.metric("Total Alerts (recent)", total_alerts)


def _parse_payload(alert: dict) -> dict:
    """Parse the payload_json field of an alert row."""
    if not alert.get("payload_json"):
        return {}
    try:
        return json.loads(alert["payload_json"])
    except (json.JSONDecodeError, TypeError):
        return {}


def _render_pending_exit_panel(cfg: dict, position: Optional[Position]):
    """Show the pending exit panel with Confirm/Dismiss buttons."""
    if position is None or not position.pending_exit:
        return

    payload = position.pending_exit_payload or {}
    col1, col2 = st.columns([3, 1])

    with col1:
        st.markdown(
            f"""
            <div style='background:{COLOR_PENDING}22; border-left:4px solid {COLOR_PENDING};
                        padding:16px; border-radius:4px; margin:8px 0;'>
                <div style='color:{COLOR_PENDING}; font-weight:700; font-size:18px;'>
                    ⚠️  PENDING EXIT — Action Required
                </div>
                <div style='margin-top:8px; color:#1e293b;'>
                    <b>Symbol:</b> {cfg['symbol']} &nbsp;|&nbsp;
                    <b>Exit date:</b> {payload.get('date', '?')}<br>
                    <b>Reason:</b> {payload.get('primary_reason', '?')} &nbsp;|&nbsp;
                    <b>Class:</b> {payload.get('primary_class', '?')}<br>
                    <b>Fill price:</b> ₹{payload.get('fill_price', 0):.2f} &nbsp;|&nbsp;
                    <b>Entry:</b> ₹{payload.get('entry_price', 0):.2f} &nbsp;|&nbsp;
                    <b>P&L:</b> <span style='color:{"#10b981" if (payload.get("pnl_pct") or 0) >= 0 else "#ef4444"};'>
                        {payload.get('pnl_pct', 0):+.2f}%
                    </span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col2:
        user_note = st.text_input("Note (optional)", key="exit_note_input",
                                    placeholder="e.g., sold at broker")

    st.markdown("<div style='height:8px;'></div>", unsafe_allow_html=True)
    btn_col1, btn_col2, btn_col3 = st.columns([1, 1, 2])

    with btn_col1:
        if st.button("✓ Confirm Exit", type="primary", use_container_width=True):
            df_d = load_df_d(cfg["data_dir"], cfg["symbol"])
            try:
                with StateStore(cfg["db_path"]) as store:
                    ok = confirm_exit(
                        state_store=store,
                        symbol=cfg["symbol"],
                        df_d=df_d,
                        divergence_cooldown_days=DIVERGENCE_COOLDOWN,
                        user_note=user_note,
                    )
                if ok:
                    st.success("Exit confirmed. Position reset, cooldown set.")
                    st.rerun()
                else:
                    st.warning("No pending exit to confirm.")
            except Exception as e:
                st.error(f"Confirm failed: {type(e).__name__}: {e}")

    with btn_col2:
        if st.button("✗ Dismiss", use_container_width=True):
            try:
                with StateStore(cfg["db_path"]) as store:
                    ok = dismiss_exit(
                        state_store=store,
                        symbol=cfg["symbol"],
                        user_note=user_note,
                    )
                if ok:
                    st.info("Exit dismissed. Position stays open, monitor will resume exit detection.")
                    st.rerun()
                else:
                    st.warning("No pending exit to dismiss.")
            except Exception as e:
                st.error(f"Dismiss failed: {type(e).__name__}: {e}")


def _render_score_chart(cfg: dict, alerts: list[dict]):
    """Score history chart with entry/exit markers."""
    st.markdown("### 📈 Score History")

    df = load_score_history(cfg["data_dir"], cfg["symbol"], cfg["start_date"], cfg["end_date"])
    if df.empty:
        st.info(f"No score data for {cfg['symbol']} in range "
                f"{cfg['start_date']} → {cfg['end_date']}. "
                f"Check the data directory and date range.")
        return

    # Filter alerts to ENTRY/EXIT/EXIT_CONFIRMED types within the date range
    entry_dates, exit_dates, confirm_dates = [], [], []
    for a in alerts:
        ts = a.get("timestamp")
        if not ts:
            continue
        try:
            ts_dt = pd.Timestamp(ts)
        except (ValueError, TypeError):
            continue
        if ts_dt < df["date"].min() or ts_dt > df["date"].max():
            continue
        a_type = a.get("alert_type")
        if a_type == ALERT_ENTRY:
            entry_dates.append(ts_dt)
        elif a_type == ALERT_EXIT:
            exit_dates.append(ts_dt)
        elif a_type == ALERT_EXIT_CONFIRMED:
            confirm_dates.append(ts_dt)

    if _PLOTLY_AVAILABLE:
        fig = go.Figure()

        # Score line
        fig.add_trace(go.Scatter(
            x=df["date"], y=df["score"],
            mode="lines", name="Score",
            line=dict(color=COLOR_PRIMARY, width=2),
            hovertemplate="Date: %{x|%Y-%m-%d}<br>Score: %{y:.1f}<extra></extra>",
        ))

        # Threshold lines
        fig.add_hline(y=cfg["entry_thresh"], line_dash="dash",
                       line_color=COLOR_ENTRY, line_width=1,
                       annotation_text=f"Entry threshold ({cfg['entry_thresh']})")
        fig.add_hline(y=cfg["exit_thresh"], line_dash="dash",
                       line_color=COLOR_EXIT, line_width=1,
                       annotation_text=f"Exit threshold ({cfg['exit_thresh']})")

        # Entry markers (green up-triangles)
        if entry_dates:
            entry_scores = []
            for d in entry_dates:
                # Find the score at this date
                mask = df["date"] == d
                if mask.any():
                    entry_scores.append(df.loc[mask, "score"].iloc[0])
                else:
                    # Find nearest
                    idx = (df["date"] - d).abs().idxmin()
                    entry_scores.append(df.loc[idx, "score"])
            fig.add_trace(go.Scatter(
                x=entry_dates, y=entry_scores,
                mode="markers", name="ENTRY",
                marker=dict(color=COLOR_ENTRY, size=12, symbol="triangle-up",
                             line=dict(width=1, color="white")),
                hovertemplate="ENTRY on %{x|%Y-%m-%d}<br>Score: %{y:.1f}<extra></extra>",
            ))

        # Exit markers (red down-triangles)
        if exit_dates:
            exit_scores = []
            for d in exit_dates:
                mask = df["date"] == d
                if mask.any():
                    exit_scores.append(df.loc[mask, "score"].iloc[0])
                else:
                    idx = (df["date"] - d).abs().idxmin()
                    exit_scores.append(df.loc[idx, "score"])
            fig.add_trace(go.Scatter(
                x=exit_dates, y=exit_scores,
                mode="markers", name="EXIT",
                marker=dict(color=COLOR_EXIT, size=12, symbol="triangle-down",
                             line=dict(width=1, color="white")),
                hovertemplate="EXIT on %{x|%Y-%m-%d}<br>Score: %{y:.1f}<extra></extra>",
            ))

        # Confirmed exit markers (gold diamonds)
        if confirm_dates:
            confirm_scores = []
            for d in confirm_dates:
                mask = df["date"] == d
                if mask.any():
                    confirm_scores.append(df.loc[mask, "score"].iloc[0])
                else:
                    idx = (df["date"] - d).abs().idxmin()
                    confirm_scores.append(df.loc[idx, "score"])
            fig.add_trace(go.Scatter(
                x=confirm_dates, y=confirm_scores,
                mode="markers", name="EXIT_CONFIRMED",
                marker=dict(color=COLOR_PENDING, size=10, symbol="diamond",
                             line=dict(width=1, color="white")),
            ))

        # v1.3: enable native scroll-wheel zoom + range slider for x-axis
        fig.update_layout(
            height=400,
            xaxis_title="Date",
            yaxis_title="Score",
            yaxis=dict(range=[0, 105]),
            hovermode="x unified",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            margin=dict(l=10, r=10, t=30, b=10),
            dragmode="zoom",  # default drag = zoom (instead of pan)
        )
        # Range slider + range selector buttons below the chart
        fig.update_xaxes(
            rangeslider=dict(visible=True, thickness=0.08),
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=3, label="3m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all", label="All"),
                ]),
                bgcolor=COLOR_MUTED,
                font=dict(color="white", size=10),
            ),
        )
        # Plotly config: enable scroll-wheel zoom + persistent mode bar
        st.plotly_chart(
            fig,
            use_container_width=True,
            config={
                "scrollZoom": True,
                "displayModeBar": True,
                "modeBarButtonsToRemove": ["lasso2d", "select2d"],
                "displaylogo": False,
            },
        )
    else:
        # Fallback: st.line_chart (no markers, but thresholds via horizontal lines)
        st.info("Install plotly for interactive chart with ENTRY/EXIT markers. "
                "Showing basic line chart.")
        chart_df = df.set_index("date")[["score"]]
        st.line_chart(chart_df, height=400)
        st.caption(f"Entry threshold: {cfg['entry_thresh']} | "
                   f"Exit threshold: {cfg['exit_thresh']} | "
                   f"Entries: {len(entry_dates)} | Exits: {len(exit_dates)}")


def _render_alerts_table(alerts: list[dict]):
    """Recent alerts table."""
    st.markdown("### 📋 Recent Alerts")
    if not alerts:
        st.info("No alerts yet. Click 'Start Monitor' to begin.")
        return

    rows = []
    for a in alerts:
        payload = _parse_payload(a)
        rows.append({
            "Timestamp": a.get("timestamp", ""),
            "Type": a.get("alert_type", ""),
            "Score": f"{payload.get('score', 0):.1f}" if payload.get("score") is not None else "—",
            "Close": f"₹{payload.get('close', 0):.2f}" if payload.get("close") else "—",
            "Message": a.get("message", ""),
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, height=1200,
                  column_config={
                      "Type": st.column_config.TextColumn(width="small"),
                      "Score": st.column_config.TextColumn(width="small"),
                      "Close": st.column_config.TextColumn(width="small"),
                  })


def _render_position_details(cfg: dict, position: Optional[Position]):
    """Detailed position state — expandable."""
    if position is None:
        return
    with st.expander("🔍 Position State Details", expanded=False):
        if position.in_trade:
            st.markdown(f"**In trade:** Yes")
            st.markdown(f"**Entry date:** {position.entry_date}")
            st.markdown(f"**Entry price:** ₹{position.entry_price:.2f}" if position.entry_price else "**Entry price:** —")
            st.markdown(f"**Peak close:** ₹{position.peak_close:.2f}" if position.peak_close else "**Peak close:** —")
            st.markdown(f"**Peak RSI:** {position.peak_rsi:.1f}" if position.peak_rsi else "**Peak RSI:** —")
            st.markdown(f"**Peak RSI date:** {position.peak_rsi_date}")
            st.markdown(f"**Peak RSI price:** ₹{position.peak_rsi_price:.2f}" if position.peak_rsi_price else "**Peak RSI price:** —")
            if position.pending_exit:
                st.markdown(f"**Pending exit:** ⚠️ Yes — confirm in panel above")
            if position.cooldown_until_date is not None:
                st.markdown(f"**Cooldown until:** {position.cooldown_until_date}")
        else:
            st.markdown("**In trade:** No")
            if position.cooldown_until_date is not None:
                st.markdown(f"**Cooldown until:** {position.cooldown_until_date}")
            else:
                st.markdown("**Status:** Ready to enter on next ENTRY signal")


# =========================================================================
# Multi-stock grid view (v1.3)
# =========================================================================

def _render_mini_chart(symbol: str, df: pd.DataFrame, position: Optional[Position],
                        alerts: list[dict], entry_thresh: float, exit_thresh: float) -> go.Figure:
    """Build a compact Plotly figure for one stock in the grid.

    Shows the score line + ENTRY/EXIT markers + threshold lines. No range
    slider (too cramped in a grid cell) — full chart appears in detail view.
    """
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["date"], y=df["score"],
        mode="lines", name="Score",
        line=dict(color=COLOR_PRIMARY, width=1.5),
        hovertemplate=f"{symbol}<br>%{{x|%Y-%m-%d}}<br>Score: %{{y:.1f}}<extra></extra>",
    ))
    fig.add_hline(y=entry_thresh, line_dash="dot", line_color=COLOR_ENTRY, line_width=1)
    fig.add_hline(y=exit_thresh, line_dash="dot", line_color=COLOR_EXIT, line_width=1)

    # ENTRY/EXIT markers (only show those in the date range)
    entry_dates, exit_dates = [], []
    for a in alerts:
        if a.get("symbol") != symbol:
            continue
        try:
            ts_dt = pd.Timestamp(a.get("timestamp"))
        except (ValueError, TypeError):
            continue
        if ts_dt < df["date"].min() or ts_dt > df["date"].max():
            continue
        if a.get("alert_type") == ALERT_ENTRY:
            entry_dates.append(ts_dt)
        elif a.get("alert_type") == ALERT_EXIT:
            exit_dates.append(ts_dt)

    for d in entry_dates:
        mask = df["date"] == d
        if mask.any():
            y = df.loc[mask, "score"].iloc[0]
            fig.add_trace(go.Scatter(
                x=[d], y=[y], mode="markers", name="ENTRY",
                marker=dict(color=COLOR_ENTRY, size=10, symbol="triangle-up"),
                showlegend=False,
                hovertemplate=f"ENTRY {symbol}<br>%{{x|%Y-%m-%d}}<extra></extra>",
            ))
    for d in exit_dates:
        mask = df["date"] == d
        if mask.any():
            y = df.loc[mask, "score"].iloc[0]
            fig.add_trace(go.Scatter(
                x=[d], y=[y], mode="markers", name="EXIT",
                marker=dict(color=COLOR_EXIT, size=10, symbol="triangle-down"),
                showlegend=False,
            ))

    fig.update_layout(
        height=220,
        margin=dict(l=5, r=5, t=30, b=5),
        yaxis=dict(range=[0, 105], title=None, tickfont=dict(size=9)),
        xaxis=dict(title=None, tickfont=dict(size=9)),
        hovermode="closest",
        showlegend=False,
    )
    return fig


def _render_grid_view(cfg: dict):
    """Multi-stock grid view: one mini-chart per stock + combined alerts feed.

    Layout:
    1. Combined alerts feed (latest 30 across ALL stocks)
    2. Pending exits across all stocks (if any)
    3. Grid of mini-charts — click a stock to expand its detail view
    4. Detail view for the selected stock (full chart + alerts + position)
    """
    available = cfg.get("available_symbols", [])
    if not available:
        st.info(
            "No stocks available for monitoring. Either drop CSV files in "
            f"`{cfg['data_dir']}` (and add them to the watchlist), or switch "
            "to Single-stock mode in the sidebar."
        )
        return

    # ===== Combined alerts feed across all stocks =====
    st.markdown("### 📡 Combined Alerts Feed (All Stocks)")
    try:
        with StateStore(cfg["db_path"]) as store:
            all_alerts = store.list_alerts_all_symbols(
                limit=50,
                alert_types=["ENTRY", "EXIT", "COOLDOWN", "EXIT_CONFIRMED", "EXIT_DISMISSED", "STARTUP"],
            )
    except Exception as e:
        st.error(f"Failed to load alerts: {e}")
        all_alerts = []

    if all_alerts:
        # Show as a compact table
        rows = []
        for a in all_alerts:
            rows.append({
                "Timestamp": a.get("timestamp", ""),
                "Symbol": a.get("symbol", ""),
                "Type": a.get("alert_type", ""),
                "Message": a.get("message", "")[:120],
            })
        st.dataframe(rows, use_container_width=True, height=1200)
    else:
        st.info("No alerts yet. Click '▶ Start Monitor' to begin scanning the watchlist.")

    st.markdown("---")

    # ===== Grid of mini-charts =====
    st.markdown(f"### 📊 Stock Grid ({len(available)} stocks)")
    st.caption("Click a stock's button to see its full chart + alerts below.")

    # Use 3 columns for the grid
    n_cols = 3
    cols = st.columns(n_cols)

    # Cache score history loading for all stocks (TTL = 5 min so monitor updates show)
    @st.cache_data(ttl=300, show_spinner=False)
    def _load_score_history_for_grid(data_dir: str, symbol: str,
                                      start_date: str, end_date: str) -> pd.DataFrame:
        return load_score_history(data_dir, symbol, start_date, end_date)

    for i, sym in enumerate(available):
        with cols[i % n_cols]:
            # Mini chart
            df = _load_score_history_for_grid(cfg["data_dir"], sym, cfg["start_date"], cfg["end_date"])
            if df.empty:
                st.warning(f"**{sym}** — no data")
                continue

            # Load this stock's alerts (for markers + position state)
            try:
                with StateStore(cfg["db_path"]) as store:
                    sym_alerts = store.list_alerts(symbol=sym, limit=100)
                    sym_position, _ = store.load_position(sym)
            except Exception:
                sym_alerts, sym_position = [], None

            # Status badge
            if sym_position:
                if sym_position.pending_exit:
                    badge_color = COLOR_PENDING
                    badge_text = "⚠️ PENDING EXIT"
                elif sym_position.in_trade:
                    badge_color = COLOR_ENTRY
                    badge_text = "🟢 IN TRADE"
                elif sym_position.cooldown_until_date is not None:
                    badge_color = COLOR_MUTED
                    badge_text = "⏸ COOLDOWN"
                else:
                    badge_color = COLOR_MUTED
                    badge_text = "⚪ FLAT"
            else:
                badge_color = COLOR_MUTED
                badge_text = "⚪ FLAT"

            st.markdown(
                f"<div style='display:flex; align-items:center; gap:8px; margin-bottom:4px;'>"
                f"<b style='font-family:monospace; font-size:14px;'>{sym}</b>"
                f"<span style='background:{badge_color}; color:white; padding:1px 6px; "
                f"border-radius:8px; font-size:10px; font-weight:600;'>{badge_text}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

            if _PLOTLY_AVAILABLE:
                fig = _render_mini_chart(
                    sym, df, sym_position, sym_alerts,
                    cfg["entry_thresh"], cfg["exit_thresh"],
                )
                st.plotly_chart(fig, use_container_width=True,
                                 config={"displayModeBar": False, "displaylogo": False})
            else:
                st.line_chart(df.set_index("date")[["score"]], height=200)

            # Latest score
            latest_score = df["score"].iloc[-1] if not df.empty else 0
            latest_date = df["date"].iloc[-1].strftime("%Y-%m-%d") if not df.empty else "?"
            st.caption(f"Latest: **{latest_score:.1f}** on {latest_date}")

            # Expand button
            if st.button(f"🔎 Expand {sym}", key=f"expand_{sym}", use_container_width=True):
                st.session_state.selected_symbol = sym
                st.rerun()

    st.markdown("---")

    # ===== Detail view for the selected stock =====
    selected = cfg.get("symbol") or st.session_state.get("selected_symbol")
    if selected:
        st.markdown(f"### 🔎 Detail View: {selected}")
        st.markdown(
            f"<div style='background:{COLOR_BG}; color:white; padding:8px 12px; "
            f"border-radius:6px; margin-bottom:12px;'>"
            f"Showing full chart + alerts + position for <b>{selected}</b>. "
            f"Click another stock above to switch."
            f"</div>",
            unsafe_allow_html=True,
        )

        # Build a single-stock cfg for the detail view (reuse v1.2 renderers)
        detail_cfg = {**cfg, "symbol": selected}

        # Load this stock's full state
        detail_position, detail_last_processed = _load_position(cfg["db_path"], selected)
        detail_alerts = _load_alerts(cfg["db_path"], selected, limit=50)

        # Pending exit panel (only for this stock)
        _render_pending_exit_panel(detail_cfg, detail_position)

        st.markdown("---")

        # Full chart with zoom + range slider
        _render_score_chart(detail_cfg, detail_alerts)

        st.markdown("---")

        # Alerts + position details side by side
        col_left, col_right = st.columns([3, 2])
        with col_left:
            _render_alerts_table(detail_alerts)
        with col_right:
            _render_position_details(detail_cfg, detail_position)

        st.caption(
            f"Last bar processed: {detail_last_processed} | "
            f"DB: {cfg['db_path']}"
        )


# =========================================================================
# Auto-refresh fragment
# =========================================================================

# Use st.fragment(run_every=...) to refresh the alerts panel without
# re-running the whole page. This keeps the UI responsive when the
# monitor is running.
try:
    @st.fragment(run_every=timedelta(seconds=5))
    def _auto_refresh_fragment():
        """Triggers a rerun of just the fragments every 5 seconds."""
        pass
except AttributeError:
    # Older Streamlit without st.fragment — define a no-op
    def _auto_refresh_fragment():
        pass


# =========================================================================
# Main
# =========================================================================

def main():
    # Page config
    st.set_page_config(
        page_title=f"Apollo Live v{LIVE_VERSION}",
        page_icon="🛰️",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # Init session state
    if "monitor_pid" not in st.session_state:
        st.session_state.monitor_pid = None
    if "selected_symbol" not in st.session_state:
        st.session_state.selected_symbol = None

    # Render UI
    _render_header()
    cfg = _render_sidebar()

    # Auto-refresh toggle (faster in multi mode — 2s)
    refresh_interval = 2 if cfg.get("multi_stock_mode") else 5
    auto_refresh = st.sidebar.checkbox(
        f"Auto-refresh ({refresh_interval}s)", value=True, key="auto_refresh_toggle"
    )
    if auto_refresh:
        _auto_refresh_fragment()

    # Manual refresh button
    if st.sidebar.button("↻ Refresh Now"):
        st.rerun()

    st.sidebar.markdown("---")
    st.sidebar.markdown(
        f"<div style='color:{COLOR_MUTED}; font-size:12px;'>"
        f"Apollo Live v{LIVE_VERSION} — built on Apollo Backtest v4.5<br>"
        f"Phase 2 Step 3 — Human-in-the-loop dashboard"
        f"</div>",
        unsafe_allow_html=True,
    )

    # Monitor controls
    _render_monitor_controls(cfg)

    st.markdown("---")

    # ===== Dispatch: multi-stock grid view vs. single-stock detail view =====
    if cfg.get("multi_stock_mode"):
        _render_grid_view(cfg)
    else:
        # Single-stock mode (v1.2 layout)
        position, last_processed = _load_position(cfg["db_path"], cfg["symbol"])
        alerts = _load_alerts(cfg["db_path"], cfg["symbol"], limit=50)

        _render_kpi_row(cfg, position, alerts)
        _render_pending_exit_panel(cfg, position)

        st.markdown("---")
        _render_score_chart(cfg, alerts)

        st.markdown("---")
        col_left, col_right = st.columns([3, 2])
        with col_left:
            _render_alerts_table(alerts)
        with col_right:
            _render_position_details(cfg, position)

        st.markdown("---")
        st.caption(
            f"Last refreshed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | "
            f"Last bar processed: {last_processed} | "
            f"DB: {cfg['db_path']}"
        )


if __name__ == "__main__":
    main()
