"""Apollo Live Engine — Phase 2 Step 4 (v1.4 — Headless Operational Release).

Core packages for live signal monitoring:
    data_replay    — bar-by-bar CSV feeder (simulates live data arrival)
    state_store    — SQLite persistence (position state + alert log)
    signal_monitor — core loop; uses apollo_core.detect_exit_triggers()
                     to emit ADVISORY alerts (does NOT auto-execute)
    watchlist      — loads my_watchlist.json, filters to CSVs on disk (v1.3)
    multi_monitor  — round-robin multi-stock monitor with paced replay (v1.3)
    dashboard      — Streamlit UI with grid view, paced replay slider,
                     chart zoom + range slider, human-in-the-loop exit
                     confirmation (v1.3)
    alert_manager  — file log + Telegram bot push, async dispatch (v1.4)
    daily_report   — per-day MD + CSV report (alerts + ranked watchlist) (v1.4)
    run_headless   — VPS-friendly entrypoint with AlertManager wiring (v1.4)
    live_feed      — abstract LiveFeed protocol + BarReplayFeed impl +
                     KiteLiveFeed stub for future Zerodha Kite integration (v1.4)
    run_live       — single launcher that starts the Streamlit dashboard

Version: 1.4 — Headless operational release (file log + Telegram + daily report + live feed abstraction)
Built on: Apollo Backtest v4.5 (ranking enrichment)
"""

from __future__ import annotations

__version__ = "1.4"
