"""Apollo v4.5 — Pre-flight Test Suite.

Run this BEFORE packaging any zip. If any test fails, the zip is NOT
shippable. No exceptions.

Usage:
    cd <project_root>
    python tests/preflight.py

Exit codes:
    0 — all tests passed (safe to package)
    1 — one or more tests failed (DO NOT package)
"""

from __future__ import annotations

import os
import sys
import subprocess
import traceback
from pathlib import Path

# Current shipped version — bump this on every release.
# Tests below verify this version appears consistently across all files.
CURRENT_VERSION = "v4.5"
CURRENT_VERSION_DOTTED = "4.5"

# Ensure project root is on sys.path
THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


# =========================================================================
# Test framework
# =========================================================================

class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.message = ""
        self.details = ""

    def __repr__(self):
        status = "PASS" if self.passed else "FAIL"
        return f"[{status}] {self.name}: {self.message}"


results: list[TestResult] = []


def run_test(name: str, fn):
    """Run a single test function and capture its result."""
    r = TestResult(name)
    try:
        msg, details = fn()
        r.passed = True
        r.message = msg
        r.details = details or ""
    except AssertionError as e:
        r.message = f"ASSERTION FAILED: {e}"
        r.details = traceback.format_exc()
    except Exception as e:
        r.message = f"ERROR: {type(e).__name__}: {e}"
        r.details = traceback.format_exc()
    results.append(r)
    print(r)
    if r.details and not r.passed:
        print(r.details)
    return r


# =========================================================================
# Test 1: Syntax check on every .py file
# =========================================================================

def test_syntax_all_files():
    """Every Python file must pass py_compile."""
    py_files = sorted(PROJECT_ROOT.rglob("*.py"))
    py_files = [f for f in py_files if "tests" not in str(f)]
    failures = []
    for f in py_files:
        try:
            subprocess.run(
                [sys.executable, "-m", "py_compile", str(f)],
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError as e:
            failures.append(f"{f.relative_to(PROJECT_ROOT)}:\n{e.stderr}")
    assert not failures, f"{len(failures)} file(s) failed syntax check:\n" + "\n".join(failures)
    return f"All {len(py_files)} Python files passed syntax check", ""


# =========================================================================
# Test 2: __future__ import ordering
# =========================================================================

def test_future_import_ordering():
    """Every 'from __future__' must be the first statement after the docstring."""
    py_files = sorted(PROJECT_ROOT.rglob("*.py"))
    py_files = [f for f in py_files if "tests" not in str(f)]
    failures = []
    for f in py_files:
        src = f.read_text(encoding="utf-8")
        lines = src.splitlines()
        # Find first non-blank line
        first_idx = None
        for i, line in enumerate(lines):
            if line.strip():
                first_idx = i
                break
        if first_idx is None:
            continue  # empty file
        # Skip docstring if present
        idx = first_idx
        if lines[idx].lstrip().startswith('"""'):
            if lines[idx].count('"""') >= 2:
                pass  # single-line docstring
            else:
                # multi-line docstring — find closing """
                idx += 1
                while idx < len(lines) and '"""' not in lines[idx]:
                    idx += 1
            idx += 1  # move past closing """
        # Now scan for code before 'from __future__'
        future_found = False
        for j in range(idx, len(lines)):
            line = lines[j]
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if stripped.startswith("from __future__"):
                future_found = True
                break
            # Found code before __future__ — only OK if no __future__ exists at all
            # But if __future__ exists later in file, this is a violation
            if any("from __future__" in l for l in lines[j+1:]):
                failures.append(
                    f"{f.relative_to(PROJECT_ROOT)} line {j+1}: "
                    f"code before __future__: {stripped!r}"
                )
            break
    assert not failures, f"{len(failures)} __future__ ordering violation(s):\n" + "\n".join(failures)
    return "All __future__ imports correctly ordered", ""


# =========================================================================
# Test 3: Import every module
# =========================================================================

def test_import_all_modules():
    """Every module must import without error."""
    modules_to_test = [
        "apollo_core",
        "apollo_core.constants",
        "apollo_core.types",
        "apollo_core.indicators",
        "apollo_core.bucket_classifier",
        "apollo_core.scoring",
        "apollo_core.ipo_lookup",
        "apollo_core.trade_engine",
        "backtest_engine",
        "backtest_engine.backtest",
        "backtest_engine.backtest_history",
        "backtest_engine.eod2_loader",
        "backtest_engine.report_generator",
    ]
    failures = []
    for mod in modules_to_test:
        try:
            __import__(mod)
        except Exception as e:
            failures.append(f"{mod}: {type(e).__name__}: {e}")
    assert not failures, f"{len(failures)} import failure(s):\n" + "\n".join(failures)
    return f"All {len(modules_to_test)} modules imported successfully", ""


# =========================================================================
# Test 4: app.py title contains correct version
# =========================================================================

def test_app_py_title_version():
    """app.py landing page title must contain the current version string
    AND a non-empty subtitle (codename) after the version."""
    app_py = PROJECT_ROOT / "backtest_engine" / "app.py"
    src = app_py.read_text(encoding="utf-8")
    expected = "Multi-timeframe RSI Recovery Scoring Engine"
    assert expected in src, f"Title prefix not found in app.py"
    assert CURRENT_VERSION in src, f"Version {CURRENT_VERSION!r} not found in app.py title"

    # Find the title line and verify it has format: "NSE Backtester vX.Y.Z — <codename>"
    title_lines = [l for l in src.splitlines() if "Multi-timeframe RSI Recovery Scoring Engine" in l]
    assert title_lines, "Title line not found in app.py"
    title_line = title_lines[0]
    assert CURRENT_VERSION in title_line, \
        f"Title line does not contain {CURRENT_VERSION}: {title_line.strip()!r}"
    # Must have a subtitle (codename) after the version, separated by em-dash
    # e.g. "v3.5 &mdash; Detect-Execute Split" or "v3.4.2 — Bucket Ungated"
    import re
    codename_match = re.search(rf"{CURRENT_VERSION}\s*[&]?mdash;\s*([^<\"]+)", title_line)
    assert codename_match, \
        f"Title line does not have a codename after {CURRENT_VERSION}: {title_line.strip()!r}"
    codename = codename_match.group(1).strip()
    assert len(codename) > 0, f"Codename is empty in title line: {title_line.strip()!r}"

    # Must NOT contain stale version strings in the title line
    stale_versions = ["v3.2", "v3.3 —", "v3.4.1 —", "v3.4.2 —", "v3.5", "v4.3", "v4.4"]
    for stale in stale_versions:
        assert stale not in title_line, \
            f"Stale version {stale!r} in title line: {title_line.strip()!r}"

    return f"app.py title correctly shows {CURRENT_VERSION} — {codename}", ""


# =========================================================================
# Test 5: run_apollo.bat points to backtest_engine\app.py
# =========================================================================

def test_bat_file_path():
    """run_apollo.bat must point to backtest_engine\\app.py (not root app.py)."""
    bat = PROJECT_ROOT / "run_apollo.bat"
    src = bat.read_text(encoding="utf-8")
    assert "streamlit run backtest_engine\\app.py" in src, \
        "run_apollo.bat must contain 'streamlit run backtest_engine\\app.py'"
    # Make sure there's no bare 'streamlit run app.py' line (without backtest_engine)
    for line in src.splitlines():
        stripped = line.strip()
        if stripped.startswith("streamlit run") and "backtest_engine" not in stripped:
            raise AssertionError(f"Found bad streamlit line in bat: {stripped!r}")
    return "run_apollo.bat correctly points to backtest_engine\\app.py", ""


# =========================================================================
# Test 6: Backtest produces expected output on CYIENTDLM
# =========================================================================

def test_backtest_cyientdlm():
    """Run a real backtest on CYIENTDLM and verify output is sane."""
    from backtest_engine.backtest import run_stock_backtest

    data_dir = PROJECT_ROOT / "data"
    csv_path = data_dir / "CYIENTDLM.csv"

    if not csv_path.exists():
        return "SKIPPED — CYIENTDLM test data not present", ""

    # Use a fixed date range so the test is reproducible
    result = run_stock_backtest(
        data_dir=str(data_dir),
        symbol="CYIENTDLM",
        start_date="2022-01-01",
        end_date="2026-07-24",
        exit_mode="NONE",
    )

    daily_df = result.get("daily_df")
    trades = result.get("trades", [])

    assert daily_df is not None and len(daily_df) > 100, \
        f"Daily results too short: {len(daily_df) if daily_df is not None else 0}"
    assert len(trades) > 0, "No trades extracted"

    # Print summary for visibility
    cum_pnl = result.get("cum_pnl", 0)
    win_rate = result.get("win_rate", 0)
    n_trades = result.get("n_trades", len(trades))

    summary = (
        f"\n      Symbol: CYIENTDLM\n"
        f"      Date range: 2022-01-01 -> 2026-07-24\n"
        f"      Daily rows: {len(daily_df)}\n"
        f"      Trades: {n_trades}\n"
        f"      Cum P&L: {cum_pnl:.2f}%\n"
        f"      Win rate: {win_rate:.1f}%\n"
    )

    return f"Backtest ran successfully on CYIENTDLM\n{summary}", ""


# =========================================================================
# Test 7: Trade engine produces deterministic output
# =========================================================================

def test_trade_engine_deterministic():
    """Running the backtest twice must produce identical results."""
    from backtest_engine.backtest import run_stock_backtest

    data_dir = PROJECT_ROOT / "data"
    csv_path = data_dir / "CYIENTDLM.csv"

    if not csv_path.exists():
        return "SKIPPED — CYIENTDLM test data not present", ""

    r1 = run_stock_backtest(
        data_dir=str(data_dir), symbol="CYIENTDLM",
        start_date="2022-01-01", end_date="2026-07-24", exit_mode="NONE",
    )
    r2 = run_stock_backtest(
        data_dir=str(data_dir), symbol="CYIENTDLM",
        start_date="2022-01-01", end_date="2026-07-24", exit_mode="NONE",
    )

    # Compare trade lists
    t1 = r1.get("trades", [])
    t2 = r2.get("trades", [])
    assert len(t1) == len(t2), f"Trade count differs: {len(t1)} vs {len(t2)}"
    for i, (a, b) in enumerate(zip(t1, t2)):
        for key in ("date", "close", "score", "pnl", "type", "exit_reason"):
            if key in a and key in b:
                assert a[key] == b[key], \
                    f"Trade {i} differs on {key}: {a[key]!r} vs {b[key]!r}"

    return f"Backtest is deterministic ({len(t1)} trades, all match on 2 runs)", ""


# =========================================================================
# Test 8: Bucket classifier does NOT skip any stock
# =========================================================================

def test_bucket_classifier_no_skip():
    """classify_stock_bucket must return a bucket for any non-empty DataFrame,
    and the backtest must NOT skip based on bucket."""
    import pandas as pd
    import numpy as np
    from apollo_core.bucket_classifier import classify_stock_bucket

    # Build a synthetic "decliner" stock that previously would have been skipped
    np.random.seed(42)
    n = 250
    dates = pd.date_range("2022-01-01", periods=n, freq="B")
    # Declining price: starts at 100, ends at ~64 (36% drop)
    prices = 100 * np.exp(-np.linspace(0, 0.45, n))
    # Add noise
    prices = prices * (1 + np.random.normal(0, 0.02, n))
    df_d = pd.DataFrame({
        "open": prices * 0.99,
        "high": prices * 1.01,
        "low": prices * 0.98,
        "close": prices,
        "volume": np.random.randint(100000, 1000000, n),
    }, index=dates)

    bucket, metrics = classify_stock_bucket(df_d)
    assert isinstance(bucket, str), f"Bucket must be a string, got {type(bucket)}"
    assert len(bucket) > 0, "Bucket must not be empty"

    # Check that there is NO 'should_skip' return value anymore
    # (only the 2-tuple form should exist)
    import inspect
    sig = inspect.signature(classify_stock_bucket)
    assert len(sig.return_annotation if hasattr(sig, 'return_annotation') else "") != 3 or \
           sig.return_annotation == tuple, \
           "classify_stock_bucket should return (bucket, metrics), not (should_skip, bucket, metrics)"

    return f"Bucket classifier returns (bucket, metrics) without skip — got bucket={bucket!r}", ""


# =========================================================================
# Test 9: All required data files present
# =========================================================================

def test_required_files_present():
    """All expected files must exist in the project root."""
    required = [
        "apollo_core/__init__.py",
        "apollo_core/constants.py",
        "apollo_core/types.py",
        "apollo_core/indicators.py",
        "apollo_core/scoring.py",
        "apollo_core/bucket_classifier.py",
        "apollo_core/ipo_lookup.py",
        "apollo_core/trade_engine.py",
        "backtest_engine/__init__.py",
        "backtest_engine/app.py",
        "backtest_engine/backtest.py",
        "backtest_engine/backtest_history.py",
        "backtest_engine/eod2_loader.py",
        "backtest_engine/report_generator.py",
        "requirements.txt",
        "run_apollo.bat",
        "run_apollo_silent.vbs",
        "ipo_listing_dates.json",
        "my_watchlist.json",
        "smallcap500.json",
        "CHANGELOG.md",
    ]
    missing = [f for f in required if not (PROJECT_ROOT / f).exists()]
    assert not missing, f"Missing required files: {missing}"
    return f"All {len(required)} required files present", ""


# =========================================================================
# Test 10: Requirements.txt is non-empty and parseable
# =========================================================================

def test_requirements_file():
    """requirements.txt must list at least the core dependencies."""
    req = PROJECT_ROOT / "requirements.txt"
    src = req.read_text(encoding="utf-8")
    lines = [l.strip() for l in src.splitlines() if l.strip() and not l.startswith("#")]
    assert len(lines) >= 3, f"requirements.txt has only {len(lines)} packages"
    # Spot-check critical packages
    req_text = "\n".join(lines).lower()
    critical = ["streamlit", "pandas", "numpy"]
    missing = [p for p in critical if p not in req_text]
    assert not missing, f"Missing critical packages in requirements.txt: {missing}"
    return f"requirements.txt OK ({len(lines)} packages)", ""


# =========================================================================
# Test 11: Universe file paths resolve correctly
# =========================================================================

def test_universe_file_paths():
    """app.py's UNIVERSE_FILES dict must point to files that actually exist.
    Files live at PROJECT ROOT, not next to app.py (which is in backtest_engine/).
    """
    # Import the app module to read its UNIVERSE_FILES dict
    # (Note: importing streamlit-heavy app.py is heavy; instead, parse the source.)
    app_py = PROJECT_ROOT / "backtest_engine" / "app.py"
    src = app_py.read_text(encoding="utf-8")

    # Find all Path(...) / "filename.json" patterns in app.py
    import re
    # Match: <something> / "<filename>.json"
    pattern = re.compile(r'/\s*"([a-zA-Z0-9_]+\.json)"')
    json_files_referenced = set(pattern.findall(src))

    # Critical universe files that MUST be referenced and MUST exist at project root
    critical_files = ["my_watchlist.json", "smallcap500.json", "ipo_listing_dates.json"]
    failures = []
    for fname in critical_files:
        # 1. Check the file exists at project root
        fpath = PROJECT_ROOT / fname
        if not fpath.exists():
            failures.append(f"{fname} not found at project root")
            continue
        # 2. Check app.py references it via a path that resolves to project root
        #    The correct pattern is: Path(__file__).resolve().parent.parent / "filename.json"
        #    (or equivalently, _project_root / "filename.json")
        #    The buggy pattern is: Path(__file__).parent / "filename.json"
        #       (resolves to backtest_engine/, which is wrong)
        if fname in json_files_referenced:
            # Check for buggy pattern: Path(__file__).parent / "filename.json"
            # (without .parent.parent)
            buggy_pattern = f'Path(__file__).parent / "{fname}"'
            buggy_pattern2 = f'Path(__file__).parent / "{fname}"'
            if buggy_pattern in src or buggy_pattern2 in src:
                # But only if there's no .parent.parent nearby — be careful
                # Actually, the safer check: scan all occurrences of the filename
                # and verify each path resolution is correct
                lines = src.splitlines()
                for i, line in enumerate(lines):
                    if fname in line and "Path(__file__)" in line:
                        if ".parent.parent" not in line and "_project_root" not in line.lower():
                            failures.append(
                                f"Line {i+1}: '{fname}' referenced via Path(__file__).parent "
                                f"without .parent.parent — will resolve to backtest_engine/ "
                                f"instead of project root. Line: {line.strip()!r}"
                            )
    assert not failures, f"{len(failures)} universe/path issue(s):\n" + "\n".join(failures)
    return "All universe file paths resolve to project root correctly", ""


# =========================================================================
# Test 12: Version string consistency across files
# =========================================================================

def test_version_consistency():
    """The current version must appear consistently in:
       - app.py UI title (HTML line)
       - app.py module docstring (Version: x.y.z — ...)
       - CHANGELOG.md (latest entry header)
    This prevents shipping a zip where the title says v3.4.2 but the docstring
    still says v3.4.1 (which has happened before).
    """
    app_py = (PROJECT_ROOT / "backtest_engine" / "app.py").read_text(encoding="utf-8")
    changelog = (PROJECT_ROOT / "CHANGELOG.md").read_text(encoding="utf-8")

    # 1. app.py UI title line must contain current version
    title_lines = [l for l in app_py.splitlines() if "Multi-timeframe RSI Recovery Scoring Engine" in l]
    assert title_lines, "Title line not found in app.py"
    assert CURRENT_VERSION in title_lines[0], \
        f"app.py title line does not contain {CURRENT_VERSION}: {title_lines[0].strip()!r}"

    # 2. app.py docstring must contain current version (dotted form, e.g. "3.4.2")
    assert f"Version: {CURRENT_VERSION_DOTTED}" in app_py, \
        f"app.py docstring does not contain 'Version: {CURRENT_VERSION_DOTTED}'"

    # 3. CHANGELOG.md must have a section for the current version
    assert f"## {CURRENT_VERSION}" in changelog, \
        f"CHANGELOG.md does not contain a '## {CURRENT_VERSION}' section"

    # 4. The current version must appear as a ## section in CHANGELOG.
    #    (Since v3.5, the CHANGELOG may contain BOTH engines' history —
    #    Apollo Live sections at the top, Apollo Backtest sections below.
    #    We no longer require v3.5 to be the FIRST section, just that it
    #    exists as a section.)
    sections = [l for l in changelog.splitlines() if l.startswith("## v")]
    assert sections, "No '## vX.Y.Z' sections found in CHANGELOG.md"
    assert any(s.startswith(f"## {CURRENT_VERSION} ") for s in sections), \
        f"No '## {CURRENT_VERSION} ...' section found in CHANGELOG.md. Sections: {sections[:3]}"

    return (
        f"Version {CURRENT_VERSION} consistent across app.py title, docstring, and CHANGELOG",
        ""
    )


# =========================================================================
# Test 13: Backtest output matches frozen v3.4.2 baseline (byte-for-byte)
# =========================================================================

def test_backtest_matches_baseline():
    """The current code's backtest output on CYIENTDLM must match the frozen
    v3.4.2 baseline (tests/baseline_v342_cyientdlm.json) byte-for-byte.

    This is the safety net for refactors like Step 1 (detect/execute split).
    If any field on any trade event changes, this test fails.

    If the baseline file doesn't exist (e.g. on user's machine without test data),
    the test SKIPS rather than fails.
    """
    import json

    baseline_path = PROJECT_ROOT / "tests" / "baseline_v342_cyientdlm.json"
    csv_path = PROJECT_ROOT / "data" / "CYIENTDLM.csv"

    if not baseline_path.exists() or not csv_path.exists():
        return "SKIPPED — baseline JSON or CYIENTDLM.csv not present", ""

    from backtest_engine.backtest import run_stock_backtest

    # Load frozen baseline
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))

    # Run current code
    result = run_stock_backtest(
        data_dir=str(PROJECT_ROOT / "data"),
        symbol="CYIENTDLM",
        start_date="2022-01-01",
        end_date="2026-07-24",
        exit_mode="NONE",
    )

    # Compare summary metrics
    assert result["n_trades"] == baseline["n_trades"], \
        f"Trade count differs: current={result['n_trades']}, baseline={baseline['n_trades']}"
    assert abs(result["cum_pnl"] - baseline["cum_pnl"]) < 0.001, \
        f"Cum P&L differs: current={result['cum_pnl']:.4f}, baseline={baseline['cum_pnl']:.4f}"
    assert abs(result["win_rate"] - baseline["win_rate"]) < 0.001, \
        f"Win rate differs: current={result['win_rate']:.4f}, baseline={baseline['win_rate']:.4f}"

    # Compare every trade event field-by-field
    current_trades = result["trades"]
    baseline_trades = baseline["trades"]
    assert len(current_trades) == len(baseline_trades), \
        f"Trade list length differs: current={len(current_trades)}, baseline={len(baseline_trades)}"

    critical_fields = ("date", "close", "score", "pnl", "type", "exit_reason",
                       "entry_price", "entry_date", "classification")

    # Normalize values for comparison. The baseline JSON has dates as ISO strings
    # (e.g. '2024-04-25T00:00:00') while the live code returns pandas Timestamps.
    # Both represent the same date — we just need to normalize before comparing.
    import numpy as np
    import pandas as pd

    def _normalize(v):
        if isinstance(v, (pd.Timestamp,)):
            return v.isoformat()
        if isinstance(v, (np.integer,)):
            return int(v)
        if isinstance(v, (np.floating,)):
            return float(v)
        if isinstance(v, (np.bool_,)):
            return bool(v)
        return v

    mismatches = []
    for i, (cur, base) in enumerate(zip(current_trades, baseline_trades)):
        for field in critical_fields:
            if field in cur and field in base:
                cur_v = _normalize(cur[field])
                base_v = _normalize(base[field])
                # For floats, allow tiny epsilon for floating-point comparison
                if isinstance(cur_v, float) and isinstance(base_v, float):
                    if abs(cur_v - base_v) > 0.0001:
                        mismatches.append(
                            f"Trade {i} field '{field}': "
                            f"current={cur_v!r} vs baseline={base_v!r} (diff={cur_v - base_v:.6f})"
                        )
                elif cur_v != base_v:
                    mismatches.append(
                        f"Trade {i} field '{field}': "
                        f"current={cur_v!r} vs baseline={base_v!r}"
                    )

    assert not mismatches, \
        f"{len(mismatches)} field mismatch(es) on CYIENTDLM trades:\n" + \
        "\n".join(mismatches[:10]) + \
        (f"\n... and {len(mismatches) - 10} more" if len(mismatches) > 10 else "")

    return (
        f"Backtest output matches v3.4.2 baseline byte-for-byte "
        f"({len(current_trades)} trades, all fields identical)",
        ""
    )


# =========================================================================
# Main runner
# =========================================================================

def main():
    print("=" * 70)
    print(f"  APOLLO {CURRENT_VERSION} — PRE-FLIGHT TEST SUITE")
    print("=" * 70)
    print(f"  Project root: {PROJECT_ROOT}")
    print(f"  Python: {sys.version.split()[0]}")
    print("=" * 70)
    print()

    run_test("1. Syntax check all .py files", test_syntax_all_files)
    run_test("2. __future__ import ordering", test_future_import_ordering)
    run_test("3. Import all modules", test_import_all_modules)
    run_test(f"4. app.py title contains {CURRENT_VERSION}", test_app_py_title_version)
    run_test("5. run_apollo.bat path correctness", test_bat_file_path)
    run_test("6. Backtest CYIENTDLM (end-to-end)", test_backtest_cyientdlm)
    run_test("7. Backtest determinism (run twice, compare)", test_trade_engine_deterministic)
    run_test("8. Bucket classifier does NOT skip", test_bucket_classifier_no_skip)
    run_test("9. All required files present", test_required_files_present)
    run_test("10. requirements.txt valid", test_requirements_file)
    run_test("11. Universe file paths resolve correctly", test_universe_file_paths)
    run_test("12. Version string consistency across files", test_version_consistency)
    run_test("13. Backtest matches v3.4.2 baseline (byte-for-byte)", test_backtest_matches_baseline)

    print()
    print("=" * 70)
    passed = sum(1 for r in results if r.passed)
    failed = sum(1 for r in results if not r.passed)
    print(f"  RESULT: {passed} passed, {failed} failed, {len(results)} total")
    print("=" * 70)

    if failed > 0:
        print()
        print("FAILED TESTS:")
        for r in results:
            if not r.passed:
                print(f"  - {r.name}: {r.message}")
        print()
        print("*** ZIP IS NOT SHIPPABLE — FIX FAILURES FIRST ***")
        sys.exit(1)
    else:
        print()
        print("*** ALL TESTS PASSED — ZIP IS SHIPPABLE ***")
        sys.exit(0)


if __name__ == "__main__":
    main()
